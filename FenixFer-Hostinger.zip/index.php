<?php
declare(strict_types=1);
require_once __DIR__ . '/app/bootstrap.php';
require_once __DIR__ . '/app/layout.php';
require_once __DIR__ . '/app/hostinger-installer.php';

$path = '/' . trim((string)(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/'), '/');
if ($path === '//') $path = '/';
$method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
if (handle_mysql_install_request($path,$method)) exit;
try { $pdo=db(); }
catch (DatabaseConfigurationRequired $error) {
    $tokenFile=APP_ROOT.'/storage/setup.token'; $token=is_file($tokenFile)?trim((string)file_get_contents($tokenFile)):'';
    if ($token!=='') redirect('/admin/install?key='.rawurlencode($token));
    http_response_code(503); header('Content-Type: text/plain; charset=utf-8'); exit('A conexão MySQL ainda não foi configurada. Restaure a chave de instalação e acesse /admin/install.');
}
catch (Throwable $error) { error_log('Fenix-Fer database startup failed (' . get_class($error) . ', code ' . (string)$error->getCode() . ').'); http_response_code(503); header('Content-Type: text/plain; charset=utf-8'); exit('Não foi possível abrir o banco de dados. Confira a configuração da hospedagem.'); }

function get_categories(bool $activeOnly = true): array
{
    $collation=db()->getAttribute(PDO::ATTR_DRIVER_NAME)==='sqlite'?' COLLATE NOCASE':'';
    $sql = 'SELECT * FROM categories' . ($activeOnly ? ' WHERE active=1' : '') . ' ORDER BY name' . $collation;
    return db()->query($sql)->fetchAll();
}
function get_product(string $slug, bool $activeOnly = true): ?array
{
    $sql = 'SELECT p.*, c.name AS category_name, c.slug AS category_slug FROM products p LEFT JOIN categories c ON c.id=p.category WHERE p.slug=:slug' . ($activeOnly ? ' AND p.active=1 AND c.active=1' : '');
    $q = db()->prepare($sql); $q->execute([':slug'=>$slug]); $r=$q->fetch(); return $r ?: null;
}
function list_products(array $options = []): array
{
    $where = []; $params = [];
    if (!empty($options['active'])) $where[] = 'p.active=1 AND c.active=1';
    if (!empty($options['featured'])) $where[] = 'p.featured=1';
    $q = trim((string)($options['q'] ?? ''));
    if ($q !== '') { $needle='%' . str_replace(['%','_'], ['\\%','\\_'], $q) . '%'; $where[] = '(p.name LIKE :q0 OR p.description LIKE :q1 OR p.specification LIKE :q2 OR c.name LIKE :q3)'; foreach([':q0',':q1',':q2',':q3'] as $key)$params[$key]=$needle; }
    $cats = array_values(array_filter((array)($options['categories'] ?? []), 'is_string'));
    if ($cats) { $marks=[]; foreach ($cats as $i=>$slug) { $key=':cat'.$i; $marks[]=$key; $params[$key]=$slug; } $where[]='c.slug IN (' . implode(',', $marks) . ')'; }
    $collation=db()->getAttribute(PDO::ATTR_DRIVER_NAME)==='sqlite'?' COLLATE NOCASE':'';
    $order = match ((string)($options['sort'] ?? 'relevant')) {
        'price_asc' => 'p.price_in_cents IS NULL, p.price_in_cents ASC, p.name' . $collation,
        'price_desc' => 'p.price_in_cents IS NULL, p.price_in_cents DESC, p.name' . $collation,
        'newest' => 'p.created DESC',
        default => 'p.featured DESC, p.created DESC',
    };
    $sql = 'SELECT p.*, c.name AS category_name, c.slug AS category_slug FROM products p LEFT JOIN categories c ON c.id=p.category';
    if ($where) $sql .= ' WHERE ' . implode(' AND ', $where);
    $sql .= ' ORDER BY ' . $order;
    $limit = isset($options['limit']) ? max(1, min(500, (int)$options['limit'])) : 500;
    $sql .= ' LIMIT ' . $limit;
    $stmt=db()->prepare($sql); $stmt->execute($params); return $stmt->fetchAll();
}
function product_by_id(string $id): ?array
{
    $q=db()->prepare('SELECT * FROM products WHERE id=:id'); $q->execute([':id'=>$id]); $r=$q->fetch(); return $r ?: null;
}
function category_by_id(string $id): ?array
{
    $q=db()->prepare('SELECT * FROM categories WHERE id=:id'); $q->execute([':id'=>$id]); $r=$q->fetch(); return $r ?: null;
}
function safe_return_to(string $candidate, string $fallback = '/'): string
{
    return str_starts_with($candidate, '/') && !str_starts_with($candidate, '//') ? $candidate : $fallback;
}
function post_string(string $key, int $max = 5000): string
{
    $value = trim((string)($_POST[$key] ?? ''));
    if (strlen($value) > $max) throw new InvalidArgumentException('Um dos campos ultrapassou o tamanho permitido.');
    return $value;
}
function checked(string $key): int { return isset($_POST[$key]) && (string)$_POST[$key] === '1' ? 1 : 0; }
function valid_image_url(string $url): bool { return $url === '' || (filter_var($url, FILTER_VALIDATE_URL) !== false && in_array(strtolower((string)parse_url($url, PHP_URL_SCHEME)), ['http','https'], true)); }
function admin_top(string $eyebrow, string $title, string $description, string $button = ''): void
{
    $current = (string)(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/');
    $links = ['/admin'=>'Visão geral','/admin/produtos'=>'Produtos','/admin/categorias'=>'Categorias'];
    if (is_admin()) { $links['/admin/configuracoes'] = 'Configurações'; $links['/admin/usuarios'] = 'Equipe'; }
    echo '<div class="admin-top"><div class="admin-top-main"><div class="admin-title"><span class="eyebrow">' . e($eyebrow) . '</span><h1>' . e($title) . '</h1><p>' . e($description) . '</p></div><div class="admin-top-actions">' . $button . '</div></div><nav class="admin-tabs" aria-label="Navegação administrativa">';
    foreach ($links as $url=>$label) echo '<a href="' . e($url) . '"' . ($current===$url?' class="is-current" aria-current="page"':'') . '>' . e($label) . '</a>';
    echo '<a class="admin-tabs-store" href="/">Abrir loja <span aria-hidden="true">↗</span></a></nav></div>';
}
function admin_form_start(string $title, string $back, string $class = ''): void
{
    echo '<div class="admin-form-wrap ' . e($class) . '"><div class="admin-form-head"><h2>' . e($title) . '</h2><a href="' . e($back) . '" aria-label="Fechar formulário">×</a></div>';
}
function input_label(string $label, string $name, string $value = '', string $attrs = '', string $type = 'text'): void
{
    echo '<label>' . e($label) . '<input type="' . e($type) . '" name="' . e($name) . '" value="' . e($value) . '" ' . $attrs . '></label>';
}

/* POST actions: all state-changing operations require a valid CSRF token. */
if ($method === 'POST') {
    verify_csrf();
    try {
        if ($path === '/admin/install') {
            $tokenFile=APP_ROOT.'/storage/setup.token'; $expected=is_file($tokenFile)?trim((string)file_get_contents($tokenFile)):''; $given=(string)($_POST['key']??'');
            if ($expected==='' || !hash_equals($expected,$given) || (int)$pdo->query('SELECT COUNT(*) FROM staff')->fetchColumn()!==0) { http_response_code(404); exit('Instalador indisponível.'); }
            $name=post_string('name',120); $email=strtolower(post_string('email',190)); $password=(string)($_POST['password']??'');
            if (!hash_equals($password,(string)($_POST['password_confirm']??''))) throw new RuntimeException('As senhas não são iguais.');
            $phoneRaw=trim(post_string('whatsapp_number',32)); $phone=preg_replace('/\\D+/', '', $phoneRaw) ?? '';
            if ($name==='' || !filter_var($email,FILTER_VALIDATE_EMAIL)) throw new RuntimeException('Informe um nome e um e-mail válidos.');
            if (strlen($password)<12) throw new RuntimeException('A senha deve ter pelo menos 12 caracteres.');
            if ($phone!=='' && (strlen($phone)<10 || strlen($phone)>15)) throw new RuntimeException('Confira o WhatsApp com código do país e DDD, ou deixe o campo vazio.');
            $sqliteTransaction=$pdo->getAttribute(PDO::ATTR_DRIVER_NAME)==='sqlite';
            if ($sqliteTransaction) $pdo->exec('BEGIN IMMEDIATE'); else $pdo->beginTransaction();
            try {
                if ((int)$pdo->query('SELECT COUNT(*) FROM staff')->fetchColumn()!==0) throw new RuntimeException('O primeiro administrador já foi criado.');
                $pdo->prepare('INSERT INTO staff(name,email,password_hash,role,active,created_at) VALUES(:name,:email,:hash,\'admin\',1,:created)')->execute([':name'=>$name,':email'=>$email,':hash'=>password_hash($password,PASSWORD_DEFAULT),':created'=>now_iso()]);
                save_app_setting('whatsapp_number',$phone);
                if ($sqliteTransaction) $pdo->exec('COMMIT'); else $pdo->commit();
            } catch (Throwable $installError) { if ($sqliteTransaction) $pdo->exec('ROLLBACK'); elseif ($pdo->inTransaction()) $pdo->rollBack(); throw $installError; }
            @unlink($tokenFile); flash('success','Instalação concluída. Entre com a conta de administrador que acabou de criar.'); redirect('/admin/login');
        }
        if ($path === '/admin/login') {
            $until=(int)($_SESSION['login_lock_until'] ?? 0);
            if ($until > time()) throw new RuntimeException('Muitas tentativas. Aguarde alguns minutos e tente novamente.');
            $email=strtolower(trim((string)($_POST['email'] ?? ''))); $password=(string)($_POST['password'] ?? '');
            $q=$pdo->prepare('SELECT * FROM staff WHERE email=:email LIMIT 1'); $q->execute([':email'=>$email]); $user=$q->fetch();
            if (!$user || !(int)$user['active'] || !password_verify($password, $user['password_hash'])) {
                $_SESSION['login_failures']=(int)($_SESSION['login_failures'] ?? 0)+1;
                if ($_SESSION['login_failures'] >= 5) { $_SESSION['login_lock_until']=time()+900; $_SESSION['login_failures']=0; }
                throw new RuntimeException('E-mail ou senha inválidos. Tente novamente.');
            }
            session_regenerate_id(true); $_SESSION['staff_id']=(int)$user['id']; unset($_SESSION['login_failures'],$_SESSION['login_lock_until']);
            $pdo->prepare('UPDATE staff SET last_login_at=:now WHERE id=:id')->execute([':now'=>now_iso(),':id'=>$user['id']]);
            flash('success','Acesso autorizado.'); redirect('/admin');
        }
        if ($path === '/admin/logout') { unset($_SESSION['staff_id']); session_regenerate_id(true); flash('info','Você saiu do painel.'); redirect('/admin/login'); }
        if (str_starts_with($path, '/carrinho/')) {
            $cart=$_SESSION['cart'] ?? [];
            if ($path === '/carrinho/adicionar') {
                $id=(string)($_POST['product_id'] ?? ''); $lookup=$pdo->prepare('SELECT p.*,c.active AS category_active FROM products p JOIN categories c ON c.id=p.category WHERE p.id=:id'); $lookup->execute([':id'=>$id]); $product=$lookup->fetch();
                if (!$product || !(int)$product['active'] || !(int)$product['category_active']) throw new RuntimeException('Este produto não está disponível.');
                if (!isset($cart[$id]) && count($cart)>=50) throw new RuntimeException('O carrinho atingiu o limite de 50 produtos diferentes.');
                $qty=max(1,min(99,(int)($_POST['quantity'] ?? 1))); $cart[$id]=min(99,(int)($cart[$id] ?? 0)+$qty); $_SESSION['cart']=$cart;
                if (is_ajax_cart_request()) { header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: no-store'); echo json_encode(['ok'=>true,'message'=>$product['name'].' adicionado ao carrinho.','cart_count'=>cart_count()],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit; }
                flash('success','Produto adicionado ao carrinho.'); redirect(safe_return_to((string)($_POST['return_to'] ?? ''), '/carrinho'));
            }
            if ($path === '/carrinho/atualizar') {
                foreach ((array)($_POST['quantity'] ?? []) as $id=>$qty) { if (isset($cart[$id])) $cart[$id]=max(1,min(99,(int)$qty)); }
                $_SESSION['cart']=$cart; flash('success','Carrinho atualizado.'); redirect('/carrinho');
            }
            if ($path === '/carrinho/remover') { unset($cart[(string)($_POST['product_id'] ?? '')]); $_SESSION['cart']=$cart; flash('info','Produto removido do carrinho.'); redirect('/carrinho'); }
            if ($path === '/carrinho/limpar') { unset($_SESSION['cart']); flash('info','Carrinho limpo.'); redirect('/carrinho'); }
        }
        if (str_starts_with($path, '/admin/')) {
            $user=require_staff();
            if ($path === '/admin/produtos/salvar') {
                $id=post_string('id',40); $existing=$id ? product_by_id($id) : null;
                if ($id && !$existing) throw new RuntimeException('Produto não encontrado.');
                $name=post_string('name',160); $slug=slugify(post_string('slug',200) ?: $name); $category=post_string('category',40);
                $description=post_string('description',2000); $spec=post_string('specification',300);
                $priceText=trim((string)($_POST['price'] ?? '')); $price=null;
                if ($priceText !== '') {
                    if (!preg_match('/^\d{1,9}(?:[,.]\d{1,2})?$/', $priceText)) throw new RuntimeException('Preço inválido. Use até duas casas decimais.');
                    $price=(int)round((float)str_replace(',', '.', $priceText)*100);
                }
                if ($name==='') throw new RuntimeException('O nome é obrigatório.');
                if ($slug==='') throw new RuntimeException('Informe um slug válido.');
                if (!category_by_id($category)) throw new RuntimeException('Selecione uma categoria válida.');
                $now=now_iso(); $newImage=save_uploaded_product_image($_FILES['image'] ?? []);
                $removeImage=checked('remove_image')===1;
                $oldImage=(string)($existing['image_path'] ?? '');
                $imagePath=$oldImage; $legacyUrl=(string)($existing['image_url'] ?? '');
                if ($newImage !== null) { $imagePath=$newImage; $legacyUrl=''; }
                elseif ($removeImage) { $imagePath=''; $legacyUrl=''; }
                try {
                    if ($existing) $sql='UPDATE products SET name=:name,slug=:slug,description=:description,specification=:specification,price_in_cents=:price,image_path=:image_path,image_url=:image_url,category=:category,active=:active,featured=:featured,updated=:updated WHERE id=:id';
                    else $sql='INSERT INTO products(id,name,slug,description,specification,price_in_cents,image_path,image_url,category,active,featured,created,updated) VALUES(:id,:name,:slug,:description,:specification,:price,:image_path,:image_url,:category,:active,:featured,:created,:updated)';
                    $stmt=$pdo->prepare($sql); $params=[':id'=>$existing['id'] ?? new_id(),':name'=>$name,':slug'=>$slug,':description'=>$description,':specification'=>$spec,':price'=>$price,':image_path'=>$imagePath,':image_url'=>$legacyUrl,':category'=>$category,':active'=>checked('active'),':featured'=>checked('featured'),':updated'=>$now];
                    if (!$existing) $params[':created']=$now;
                    $stmt->execute($params);
                } catch (Throwable $saveError) {
                    discard_new_product_image($newImage);
                    throw $saveError;
                }
                if ($existing && ($newImage !== null || $removeImage)) delete_product_image_if_unused($oldImage);
                flash('success',$newImage !== null ? 'Produto e imagem salvos com sucesso.' : 'Produto salvo com sucesso.'); redirect('/admin/produtos');
            }
            if ($path === '/admin/configuracoes/salvar') {
                require_staff(true); $raw=trim(post_string('whatsapp_number',32)); $phone=preg_replace('/\\D+/', '', $raw) ?? '';
                if ($phone!=='' && (strlen($phone)<10 || strlen($phone)>15)) throw new RuntimeException('Informe o número com código do país e DDD, ou deixe vazio.');
                save_app_setting('whatsapp_number',$phone); flash('success','Configuração de atendimento salva.'); redirect('/admin/configuracoes');
            }
            if ($path === '/admin/produtos/alternar') {
                $product=product_by_id(post_string('id',40)); if (!$product) throw new RuntimeException('Produto não encontrado.');
                $field=(string)($_POST['field'] ?? ''); if (!in_array($field,['active','featured'],true)) throw new RuntimeException('Ação inválida.');
                $pdo->prepare("UPDATE products SET $field=:value,updated=:updated WHERE id=:id")->execute([':value'=>!(int)$product[$field],':updated'=>now_iso(),':id'=>$product['id']]); flash('success','Status do produto atualizado.'); redirect('/admin/produtos');
            }
            if ($path === '/admin/produtos/excluir') {
                if ($user['role']!=='admin') throw new RuntimeException('Somente administrador pode excluir produtos.');
                $product=product_by_id(post_string('id',40)); if (!$product) throw new RuntimeException('Produto não encontrado.');
                $pdo->prepare('DELETE FROM products WHERE id=:id')->execute([':id'=>$product['id']]); delete_product_image_if_unused((string)($product['image_path'] ?? '')); flash('success','Produto excluído.'); redirect('/admin/produtos');
            }
            if ($path === '/admin/categorias/salvar') {
                $id=post_string('id',40); $existing=$id ? category_by_id($id) : null;
                if ($id && !$existing) throw new RuntimeException('Categoria não encontrada.');
                $name=post_string('name',120); $slug=slugify(post_string('slug',160) ?: $name); $description=post_string('description',600); $image=post_string('image_url',2048);
                if ($name==='') throw new RuntimeException('O nome é obrigatório.'); if ($slug==='') throw new RuntimeException('Informe um slug válido.'); if (!valid_image_url($image)) throw new RuntimeException('URL da imagem inválida.');
                $now=now_iso();
                if ($existing) $sql='UPDATE categories SET name=:name,slug=:slug,description=:description,image_url=:image,active=:active,updated=:updated WHERE id=:id';
                else $sql='INSERT INTO categories(id,name,slug,description,image_url,active,created,updated) VALUES(:id,:name,:slug,:description,:image,:active,:created,:updated)';
                $stmt=$pdo->prepare($sql); $params=[':id'=>$existing['id'] ?? new_id(),':name'=>$name,':slug'=>$slug,':description'=>$description,':image'=>$image,':active'=>checked('active'),':updated'=>$now]; if (!$existing) $params[':created']=$now; $stmt->execute($params);
                flash('success','Categoria salva com sucesso.'); redirect('/admin/categorias');
            }
            if ($path === '/admin/categorias/alternar') {
                $category=category_by_id(post_string('id',40)); if (!$category) throw new RuntimeException('Categoria não encontrada.');
                $pdo->prepare('UPDATE categories SET active=:active,updated=:updated WHERE id=:id')->execute([':active'=>!(int)$category['active'],':updated'=>now_iso(),':id'=>$category['id']]); flash('success','Status da categoria atualizado.'); redirect('/admin/categorias');
            }
            if ($path === '/admin/categorias/excluir') {
                if ($user['role']!=='admin') throw new RuntimeException('Somente administrador pode excluir categorias.');
                $id=post_string('id',40); $countQ=$pdo->prepare('SELECT COUNT(*) FROM products WHERE category=:id'); $countQ->execute([':id'=>$id]);
                if ((int)$countQ->fetchColumn()>0) throw new RuntimeException('Não é possível excluir categoria com produtos vinculados.');
                $pdo->prepare('DELETE FROM categories WHERE id=:id')->execute([':id'=>$id]); flash('success','Categoria excluída.'); redirect('/admin/categorias');
            }
            if ($path === '/admin/usuarios/salvar') {
                require_staff(true); $id=(int)($_POST['id'] ?? 0); $name=post_string('name',120); $email=strtolower(post_string('email',190)); $role=(string)($_POST['role'] ?? 'editor'); $password=(string)($_POST['password'] ?? '');
                if ($name==='' || !filter_var($email,FILTER_VALIDATE_EMAIL)) throw new RuntimeException('Informe nome e e-mail válidos.'); if (!in_array($role,['admin','editor'],true)) throw new RuntimeException('Papel inválido.');
                if ($id) {
                    $q=$pdo->prepare('SELECT * FROM staff WHERE id=:id'); $q->execute([':id'=>$id]); $old=$q->fetch(); if (!$old) throw new RuntimeException('Usuário não encontrado.');
                    $active=checked('active'); if ($id===(int)$user['id'] && !$active) throw new RuntimeException('Não é possível desativar sua própria conta.');
                    if ($password!=='') { if (strlen($password)<12) throw new RuntimeException('A senha deve ter pelo menos 12 caracteres.'); $pdo->prepare('UPDATE staff SET name=:name,email=:email,role=:role,active=:active,password_hash=:hash WHERE id=:id')->execute([':name'=>$name,':email'=>$email,':role'=>$role,':active'=>$active,':hash'=>password_hash($password,PASSWORD_DEFAULT),':id'=>$id]); }
                    else $pdo->prepare('UPDATE staff SET name=:name,email=:email,role=:role,active=:active WHERE id=:id')->execute([':name'=>$name,':email'=>$email,':role'=>$role,':active'=>$active,':id'=>$id]);
                } else {
                    if (strlen($password)<12) throw new RuntimeException('A senha deve ter pelo menos 12 caracteres.');
                    $pdo->prepare('INSERT INTO staff(name,email,password_hash,role,active,created_at) VALUES(:name,:email,:hash,:role,1,:created)')->execute([':name'=>$name,':email'=>$email,':hash'=>password_hash($password,PASSWORD_DEFAULT),':role'=>$role,':created'=>now_iso()]);
                }
                flash('success','Usuário salvo com sucesso.'); redirect('/admin/usuarios');
            }
            if ($path === '/admin/usuarios/alternar') {
                require_staff(true); $id=(int)($_POST['id'] ?? 0); if ($id===(int)$user['id']) throw new RuntimeException('Não é possível desativar sua própria conta.');
                $pdo->prepare('UPDATE staff SET active=CASE WHEN active=1 THEN 0 ELSE 1 END WHERE id=:id')->execute([':id'=>$id]); flash('success','Acesso do usuário atualizado.'); redirect('/admin/usuarios');
            }
            if ($path === '/admin/usuarios/excluir') {
                require_staff(true); $id=(int)($_POST['id'] ?? 0); if ($id===(int)$user['id']) throw new RuntimeException('Não é possível excluir sua própria conta.');
                $pdo->prepare('DELETE FROM staff WHERE id=:id')->execute([':id'=>$id]); flash('success','Usuário excluído.'); redirect('/admin/usuarios');
            }
        }
        throw new RuntimeException('Ação não reconhecida.');
    } catch (Throwable $error) {
        if ($error instanceof PDOException && ($error->getCode()==='23000' || str_contains(strtolower($error->getMessage()), 'unique') || str_contains(strtolower($error->getMessage()), 'duplicate entry'))) $message='Esse slug ou e-mail já está cadastrado.';
        elseif ($error instanceof RuntimeException || $error instanceof InvalidArgumentException) $message=$error->getMessage();
        else { error_log((string)$error); $message='Não foi possível concluir a operação. Verifique os dados e tente novamente.'; }
        if (is_ajax_cart_request()) { http_response_code($error instanceof RuntimeException ? 422 : 500); header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: no-store'); echo json_encode(['ok'=>false,'message'=>$message],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit; }
        flash('error',$message);
        $fallback = str_starts_with($path,'/admin/') ? dirname($path) : '/carrinho';
        redirect(safe_return_to((string)($_POST['return_to'] ?? $fallback), $fallback));
    }
}

if ($method==='GET' && preg_match('~^/media/products/([a-f0-9]{40}\.(?:jpg|png|webp))$~', $path, $mediaMatch)) {
    $filename=$mediaMatch[1]; $file=APP_ROOT.'/storage/uploads/products/'.$filename;
    if (!is_file($file) || is_link($file)) { http_response_code(404); exit; }
    $mime=(new finfo(FILEINFO_MIME_TYPE))->file($file); $allowed=['jpg'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp'];
    $extension=pathinfo($filename,PATHINFO_EXTENSION);
    if (!isset($allowed[$extension]) || $mime!==$allowed[$extension]) { http_response_code(404); exit; }
    $etag='"'.$filename.'"'; header('Content-Type: '.$mime); header('X-Content-Type-Options: nosniff'); header('Cross-Origin-Resource-Policy: same-site'); header('Cache-Control: public, max-age=31536000, immutable'); header('ETag: '.$etag); header('Content-Length: '.(string)filesize($file));
    if (trim((string)($_SERVER['HTTP_IF_NONE_MATCH']??''))===$etag) { http_response_code(304); exit; }
    readfile($file); exit;
}

if ($path === '/api/health') {
    header('Content-Type: application/json; charset=utf-8'); echo json_encode(['ok'=>true,'database'=>$pdo->getAttribute(PDO::ATTR_DRIVER_NAME),'time'=>now_iso()], JSON_UNESCAPED_UNICODE); exit;
}
if ($path === '/api/categories') {
    header('Content-Type: application/json; charset=utf-8'); echo json_encode(['data'=>get_categories(true)], JSON_UNESCAPED_UNICODE); exit;
}
if ($path === '/api/products') {
    $page=max(1,min(1000,(int)($_GET['page'] ?? 1))); $limit=max(1,min(100,(int)($_GET['limit'] ?? 20)));
    $all=list_products(['active'=>true,'q'=>substr((string)($_GET['q'] ?? ''),0,100),'categories'=>!empty($_GET['category'])?[(string)$_GET['category']]:[],'sort'=>(string)($_GET['order'] ?? 'relevant')]);
    $total=count($all); $rows=array_slice($all,($page-1)*$limit,$limit);
    $data=array_map(fn($p)=>['id'=>$p['id'],'name'=>$p['name'],'slug'=>$p['slug'],'category'=>$p['category_name'],'category_slug'=>$p['category_slug'],'specification'=>$p['specification'],'image'=>product_image_ref($p),'price'=>$p['price_in_cents'],'price_formatted'=>money($p['price_in_cents']===null?null:(int)$p['price_in_cents']),'url'=>'/produto/'.$p['slug'],'available'=>(bool)$p['active']],$rows);
    header('Content-Type: application/json; charset=utf-8'); echo json_encode(['data'=>$data,'meta'=>['page'=>$page,'limit'=>$limit,'total'=>$total,'pages'=>(int)ceil($total/$limit)]],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit;
}

/* Administration login screen and protected routes. */
if ($path === '/admin/install') {
    $tokenFile=APP_ROOT.'/storage/setup.token'; $expected=is_file($tokenFile)?trim((string)file_get_contents($tokenFile)):''; $given=is_string($_GET['key']??null)?$_GET['key']:'';
    if ($expected==='' || !hash_equals($expected,$given) || (int)$pdo->query('SELECT COUNT(*) FROM staff')->fetchColumn()!==0) { http_response_code(404); exit('Instalador indisponível.'); }
    page_start('Instalação inicial — Fenix-Fer','Crie o acesso administrativo da sua loja.');
    echo '<main class="admin-login-page"><div class="admin-login-box"><div class="admin-login-icon">' . icon_svg('package',23) . '</div><span class="eyebrow">CONFIGURAÇÃO INICIAL · ETAPA ÚNICA</span><h1>Prepare sua loja</h1><p>Crie seu acesso de administrador e informe o WhatsApp que receberá os pedidos de orçamento.</p><form method="post" action="/admin/install">' . csrf_field() . '<input type="hidden" name="key" value="' . e($given) . '">';
    input_label('Seu nome','name','','required maxlength="120" autocomplete="name"'); input_label('E-mail administrativo','email','','required maxlength="190" autocomplete="email"','email'); input_label('Senha (mínimo 12 caracteres)','password','','required minlength="12" autocomplete="new-password"','password'); input_label('Confirme a senha','password_confirm','','required minlength="12" autocomplete="new-password"','password'); input_label('WhatsApp com código do país e DDD (opcional)','whatsapp_number','','maxlength="32" placeholder="5511999999999" autocomplete="tel"');
    echo '<button class="primary-button" type="submit">CRIAR ADMINISTRADOR</button></form><p class="install-security-note">Esta chave é de uso único. Depois de criar sua conta, o instalador se desativa.</p></div></main>'; page_end(); exit;
}
if ($path === '/admin/login') {
    if (current_user()) redirect('/admin');
    page_start('Acesso administrativo','Acesso reservado à equipe da Fenix-Fer.');
    echo '<main class="admin-login-page"><div class="admin-login-box"><div class="admin-login-icon">' . icon_svg('package',23) . '</div><span class="eyebrow">ÁREA RESTRITA</span><h1>Painel Fenix-Fer</h1><p>Acesse com as credenciais da sua equipe.</p><form method="post" action="/admin/login">' . csrf_field();
    input_label('E-mail','email','', 'required autocomplete="username" maxlength="190"','email'); input_label('Senha','password','', 'required autocomplete="current-password"','password');
    echo '<button class="primary-button" type="submit">ENTRAR →</button></form><a class="back-store" href="/">' . icon_svg('arrow-right',14) . ' Voltar para a loja</a></div></main>'; page_end(); exit;
}
if (str_starts_with($path,'/admin')) {
    $admin=require_staff();
    if ($path === '/admin/configuracoes') {
        require_staff(true); $q=$pdo->prepare("SELECT setting_value FROM app_settings WHERE setting_key='whatsapp_number'"); $q->execute(); $phone=(string)($q->fetchColumn() ?: '');
        page_start('Configurações — Painel','Configuração do atendimento da loja.'); echo '<main class="admin-page"><div class="breadcrumb"><a href="/admin">Painel</a> / Configurações</div>';
        admin_top('LOJA','Configurações','Defina o contato usado nos pedidos de orçamento e nas conversas com clientes.');
        admin_form_start('WhatsApp da loja','/admin/configuracoes'); echo '<form class="admin-form settings-form" method="post" action="/admin/configuracoes/salvar">' . csrf_field(); input_label('Número com código do país e DDD','whatsapp_number',$phone,'maxlength="32" placeholder="5511999999999" autocomplete="tel"');
        echo '<p class="settings-help">Use apenas o número completo, por exemplo: 55 + DDD + número. Deixe em branco para não definir um destino. Os pedidos continuarão sendo montados com a lista de produtos.</p><button class="primary-button" type="submit">SALVAR CONFIGURAÇÕES</button></form></div><a class="back-store" href="/admin">' . icon_svg('arrow-right',14) . ' Voltar ao painel</a></main>'; page_end(); exit;
    }
    if ($path === '/admin') {
        page_start('Painel administrativo','Área administrativa da Fenix-Fer.');
        $productsTotal=(int)$pdo->query('SELECT COUNT(*) FROM products')->fetchColumn();
        $activeProducts=(int)$pdo->query('SELECT COUNT(*) FROM products WHERE active=1')->fetchColumn();
        $categoriesTotal=(int)$pdo->query('SELECT COUNT(*) FROM categories')->fetchColumn();
        echo '<main class="admin-page"><div class="breadcrumb"><a href="/">Loja</a> / Painel</div>';
        admin_top('ÁREA ADMINISTRATIVA','Olá, ' . ($admin['name'] ?: 'equipe') . '.', 'Gerencie o catálogo e mantenha sua loja sempre atualizada.', '<form method="post" action="/admin/logout" class="admin-logout-form">' . csrf_field() . '<button class="secondary-button" type="submit">Sair do painel</button></form>');
        echo '<section class="admin-welcome"><div class="admin-welcome-copy"><span class="admin-welcome-kicker">FENIX-FER · PAINEL DA LOJA</span><h2>Seu trabalho faz a loja acontecer.</h2><p>Gerencie seus produtos, organize categorias e deixe tudo pronto para atender bem cada cliente.</p><a href="/produtos" class="admin-welcome-link">VISUALIZAR A LOJA <span aria-hidden="true">↗</span></a></div><div class="admin-welcome-mark" aria-hidden="true"><span>F</span><small>FENIX<br>FER</small></div></section>';
        echo '<section class="admin-metrics" aria-label="Resumo do catálogo"><article class="admin-metric"><span class="admin-metric-icon">' . icon_svg('package',19) . '</span><div><small>PRODUTOS CADASTRADOS</small><strong>' . $productsTotal . '</strong></div><span class="admin-metric-foot">' . $activeProducts . ' ativos na loja</span></article><article class="admin-metric"><span class="admin-metric-icon">' . icon_svg('grid',19) . '</span><div><small>CATEGORIAS</small><strong>' . $categoriesTotal . '</strong></div><span class="admin-metric-foot">Organização do catálogo</span></article><article class="admin-metric admin-metric-note"><span class="admin-metric-icon">' . icon_svg('chat',19) . '</span><div><small>ATENDIMENTO</small><strong>WhatsApp</strong></div><span class="admin-metric-foot">Orçamentos direto com a equipe</span></article></section>';
        echo '<div class="admin-section-heading"><div><span class="eyebrow">ATALHOS DO PAINEL</span><h2>O que você quer gerenciar?</h2></div></div><div class="admin-links"><a href="/admin/produtos" class="admin-feature"><span class="admin-card-icon">' . icon_svg('package',19) . '</span><span class="admin-card-kicker">CATÁLOGO</span><h2>Produtos</h2><p>Cadastre novos itens, atualize preços, destaque produtos e controle o que fica visível.</p><span class="admin-feature-link">GERENCIAR PRODUTOS <b>→</b></span></a><a href="/admin/categorias" class="admin-feature"><span class="admin-card-icon">' . icon_svg('grid',19) . '</span><span class="admin-card-kicker">ORGANIZAÇÃO</span><h2>Categorias</h2><p>Organize o catálogo para facilitar a busca e a escolha dos seus clientes.</p><span class="admin-feature-link">GERENCIAR CATEGORIAS <b>→</b></span></a>';
        if ($admin['role']==='admin') echo '<a href="/admin/usuarios" class="admin-feature"><span class="admin-card-icon">' . icon_svg('users',19) . '</span><span class="admin-card-kicker">ACESSO DA EQUIPE</span><h2>Usuários</h2><p>Gerencie os acessos de administradores e editores do painel.</p><span class="admin-feature-link">GERENCIAR EQUIPE <b>→</b></span></a>';
        echo '<a href="/produtos" class="admin-feature admin-feature-public"><span class="admin-card-icon">' . icon_svg('arrow-up-right',19) . '</span><span class="admin-card-kicker">VITRINE PÚBLICA</span><h2>Ver a loja</h2><p>Confira o catálogo e a experiência que seus clientes estão vendo.</p><span class="admin-feature-link">ABRIR CATÁLOGO <b>→</b></span></a></div><div class="admin-note"><span class="admin-note-mark">' . icon_svg('info',15) . '</span><div><h2>As alterações aparecem na loja imediatamente</h2><p>Antes de sair do painel, confira os produtos ativos e as informações do catálogo.</p></div></div></main>';
        page_end(); exit;
    }
    if ($path === '/admin/produtos') {
        $products=$pdo->query('SELECT p.*,c.name AS category_name FROM products p LEFT JOIN categories c ON c.id=p.category ORDER BY p.created DESC')->fetchAll(); $categories=get_categories(false);
        $q=trim((string)($_GET['q'] ?? '')); $filterCategory=(string)($_GET['categoria'] ?? '');
        if ($q!=='') $products=array_values(array_filter($products,fn($p)=>stripos($p['name'],$q)!==false));
        if ($filterCategory!=='') $products=array_values(array_filter($products,fn($p)=>$p['category']===$filterCategory));
        $edit=isset($_GET['edit'])?product_by_id((string)$_GET['edit']):null; $creating=isset($_GET['novo']);
        page_start('Produtos — Painel','Gerenciamento de produtos.'); echo '<main class="admin-page"><div class="breadcrumb"><a href="/admin">Painel</a> / Produtos</div>';
        admin_top('CATÁLOGO','Produtos','Cadastre, edite e controle os produtos da loja.','<a class="primary-button" href="/admin/produtos?novo=1">' . icon_svg('plus',15) . ' NOVO PRODUTO</a>');
        if ($edit || $creating) {
            $p=$edit ?? ['id'=>'','name'=>'','slug'=>'','category'=>$categories[0]['id']??'','description'=>'','specification'=>'','price_in_cents'=>null,'image_path'=>'','image_url'=>'','active'=>1,'featured'=>0];
            admin_form_start($edit?'Editar produto':'Novo produto','/admin/produtos'); echo '<form class="admin-form" method="post" enctype="multipart/form-data" action="/admin/produtos/salvar" data-image-upload>' . csrf_field() . '<input type="hidden" name="MAX_FILE_SIZE" value="5242880"><input type="hidden" name="id" value="' . e($p['id']) . '">';
            input_label('Nome','name',$p['name'],'required maxlength="160"'); input_label('Slug (URL)','slug',$p['slug'],'maxlength="200"');
            echo '<label>Categoria<select name="category" required>'; foreach($categories as $c) echo '<option value="' . e($c['id']) . '"' . ($p['category']===$c['id']?' selected':'') . '>' . e($c['name']) . '</option>'; echo '</select></label>';
            input_label('Especificação','specification',$p['specification'],'maxlength="300"'); input_label('Preço (R$) — vazio = consulte','price',$p['price_in_cents']===null?'':number_format((int)$p['price_in_cents']/100,2,',',''),'inputmode="decimal"');
            $preview=product_image_ref($p);
            echo '<div class="admin-upload-field"><div class="admin-upload-heading"><span class="admin-upload-icon">' . icon_svg('image',19) . '</span><div><strong>Imagem do produto</strong><small>Selecione um arquivo no seu dispositivo. JPG, PNG ou WebP · até 5 MB.</small></div></div><div class="admin-upload-controls"><label class="admin-upload-picker"><span>' . icon_svg('image',16) . ' Escolher imagem</span><input type="file" name="image" accept="image/jpeg,image/png,image/webp" data-product-image></label><div class="admin-image-preview" data-image-preview>' . image_or_placeholder($preview,$p['name'] ?: 'Prévia da imagem') . '</div></div>';
            if ($preview!=='') echo '<label class="remove-image-option"><input type="checkbox" name="remove_image" value="1"> Remover a imagem atual (se não enviar outra)</label>';
            if (!empty($p['image_url']) && empty($p['image_path'])) echo '<small class="legacy-image-note">Esta imagem antiga continuará visível até você enviar uma imagem nova.</small>';
            echo '</div><label class="description-field">Descrição<textarea name="description" rows="4" maxlength="2000">' . e($p['description']) . '</textarea></label><label class="active-field"><input type="checkbox" name="active" value="1"' . ((int)$p['active']?' checked':'') . '> Produto ativo (visível na loja)</label><label class="active-field"><input type="checkbox" name="featured" value="1"' . ((int)$p['featured']?' checked':'') . '> Marcar como destaque</label><button class="primary-button" type="submit">SALVAR PRODUTO</button></form></div>';
        }
        echo '<div class="admin-user-list"><div class="admin-user-list-title"><strong>Produtos cadastrados</strong><span>' . count($products) . ' item(ns)</span></div><form class="admin-toolbar" method="get"><input name="q" value="' . e($q) . '" placeholder="Buscar por nome…"><select name="categoria"><option value="">Todas as categorias</option>'; foreach($categories as $c) echo '<option value="' . e($c['id']) . '"' . ($filterCategory===$c['id']?' selected':'') . '>' . e($c['name']) . '</option>'; echo '</select><button class="secondary-button">Filtrar</button></form>';
        if (!$products) echo '<p class="empty-admin">Nenhum produto encontrado.</p>';
        foreach($products as $p) {
            echo '<div class="admin-user-row"><div class="cart-thumbnail" style="width:52px;height:52px;flex:0 0 52px">' . image_or_placeholder(product_image_ref($p),$p['name']) . '</div><div class="user-data"><strong>' . e($p['name']) . '</strong><span>' . e($p['category_name'] ?? '—') . ' · ' . e($p['specification'] ?: 'sem especificação') . '</span></div><span class="user-role">' . e(money($p['price_in_cents']===null?null:(int)$p['price_in_cents'])) . '</span><span class="user-status ' . ((int)$p['active']?'is-active':'') . '">' . ((int)$p['active']?'Ativo':'Inativo') . '</span><div class="admin-actions"><a href="/admin/produtos?edit=' . rawurlencode($p['id']) . '">Editar</a>';
            foreach(['active'=>'Ativar/Desativar','featured'=>'Destaque'] as $field=>$label) echo '<form method="post" action="/admin/produtos/alternar">' . csrf_field() . '<input type="hidden" name="id" value="' . e($p['id']) . '"><input type="hidden" name="field" value="' . e($field) . '"><button type="submit">' . ($field==='active'?((int)$p['active']?'Desativar':'Ativar'):((int)$p['featured']?'Remover destaque':'Destacar')) . '</button></form>';
            if ($admin['role']==='admin') echo '<form method="post" action="/admin/produtos/excluir" onsubmit="return confirm(\'Excluir este produto?\')">' . csrf_field() . '<input type="hidden" name="id" value="' . e($p['id']) . '"><button type="submit">Excluir</button></form>';
            echo '</div></div>';
        }
        echo '</div><a class="back-store" href="/admin">← Voltar ao painel</a></main>'; page_end(); exit;
    }
    if ($path === '/admin/categorias') {
        $categories=get_categories(false); $counts=[]; foreach($pdo->query('SELECT category,COUNT(*) AS n FROM products GROUP BY category')->fetchAll() as $r)$counts[$r['category']]=(int)$r['n'];
        $edit=isset($_GET['edit'])?category_by_id((string)$_GET['edit']):null; $creating=isset($_GET['novo']); page_start('Categorias — Painel','Gerenciamento de categorias.'); echo '<main class="admin-page"><div class="breadcrumb"><a href="/admin">Painel</a> / Categorias</div>';
        admin_top('ORGANIZAÇÃO','Categorias','Organize o catálogo e acompanhe quantos produtos pertencem a cada seção.','<a class="primary-button" href="/admin/categorias?novo=1">' . icon_svg('plus',15) . ' NOVA CATEGORIA</a>');
        $activeCategoryCount=count(array_filter($categories,static fn($c)=>(int)$c['active']===1));
        echo '<section class="category-admin-overview"><div><span class="category-overview-icon">' . icon_svg('grid',21) . '</span><strong>' . count($categories) . '</strong><small>CATEGORIAS NO CATÁLOGO</small></div><div><span class="category-overview-icon is-green">' . icon_svg('check',21) . '</span><strong>' . $activeCategoryCount . '</strong><small>VISÍVEIS NA LOJA</small></div><p>As categorias organizam os filtros e ajudam seus clientes a encontrar os produtos. Desativar uma categoria oculta seus produtos da loja sem apagá-los.</p></section>';
        if ($edit || $creating) {
            $c=$edit ?? ['id'=>'','name'=>'','slug'=>'','description'=>'','image_url'=>'','active'=>1]; admin_form_start($edit?'Editar categoria':'Nova categoria','/admin/categorias'); echo '<form class="admin-form" method="post" action="/admin/categorias/salvar">' . csrf_field() . '<input type="hidden" name="id" value="' . e($c['id']) . '">';
            input_label('Nome','name',$c['name'],'required maxlength="120"'); input_label('Slug (URL)','slug',$c['slug'],'maxlength="160"'); input_label('URL da imagem (opcional)','image_url',$c['image_url'],'placeholder="https://…"');
            echo '<label class="active-field"><input type="checkbox" name="active" value="1"' . ((int)$c['active']?' checked':'') . '> Categoria ativa</label><label class="description-field">Descrição<textarea name="description" rows="3" maxlength="600">' . e($c['description']) . '</textarea></label><button class="primary-button" type="submit">SALVAR CATEGORIA</button></form></div>';
        }
        echo '<div class="category-admin-list-heading"><div><span class="eyebrow">ORGANIZAÇÃO DA VITRINE</span><h2>Suas categorias</h2></div><span>' . count($categories) . ' no total</span></div><div class="category-admin-grid">';
        foreach($categories as $c) {
            $productCount=(int)($counts[$c['id']]??0); $icon=category_icon_name($c['name']);
            echo '<article class="category-admin-card"><div class="category-admin-card-head"><span class="category-admin-icon">' . icon_svg($icon,22) . '</span><span class="user-status ' . ((int)$c['active']?'is-active':'') . '">' . ((int)$c['active']?'Ativa':'Inativa') . '</span></div><h3>' . e($c['name']) . '</h3><span class="category-admin-slug">/' . e($c['slug']) . '</span><div class="category-admin-count"><strong>' . $productCount . '</strong><span>' . ($productCount===1?'produto vinculado':'produtos vinculados') . '</span></div><div class="category-admin-actions"><a href="/admin/categorias?edit=' . rawurlencode($c['id']) . '">' . icon_svg('edit',14) . ' Editar</a><form method="post" action="/admin/categorias/alternar">' . csrf_field() . '<input type="hidden" name="id" value="' . e($c['id']) . '"><button type="submit">' . ((int)$c['active']?'Desativar':'Ativar') . '</button></form>';
            if ($admin['role']==='admin' && $productCount===0) echo '<form method="post" action="/admin/categorias/excluir" onsubmit="return confirm(&quot;Excluir esta categoria?&quot;)">' . csrf_field() . '<input type="hidden" name="id" value="' . e($c['id']) . '"><button type="submit">Excluir</button></form>';
            echo '</div></article>';
        }
        echo '</div><a class="back-store" href="/admin">' . icon_svg('arrow-right',14) . ' Voltar ao painel</a></main>'; page_end(); exit;
    }
    if ($path === '/admin/usuarios') {
        require_staff(true); $sortCollation=$pdo->getAttribute(PDO::ATTR_DRIVER_NAME)==='sqlite'?' COLLATE NOCASE':''; $users=$pdo->query('SELECT id,name,email,role,active,last_login_at,created_at FROM staff ORDER BY name'.$sortCollation)->fetchAll();
        $edit=null; if (isset($_GET['edit'])) { $s=$pdo->prepare('SELECT id,name,email,role,active FROM staff WHERE id=:id'); $s->execute([':id'=>(int)$_GET['edit']]); $edit=$s->fetch() ?: null; }
        $creating=isset($_GET['novo']); page_start('Equipe — Painel','Gerenciamento de acessos internos.'); echo '<main class="admin-page"><div class="breadcrumb"><a href="/admin">Painel</a> / Equipe</div>';
        admin_top('ACESSO','Usuários da equipe','Gerencie as contas que podem acessar o painel.','<a class="primary-button" href="/admin/usuarios?novo=1">' . icon_svg('plus',15) . ' NOVO USUÁRIO</a>');
        if ($edit || $creating) {
            $u=$edit ?? ['id'=>'','name'=>'','email'=>'','role'=>'editor','active'=>1]; admin_form_start($edit?'Editar usuário':'Novo usuário','/admin/usuarios'); echo '<form class="admin-form" method="post" action="/admin/usuarios/salvar">' . csrf_field() . '<input type="hidden" name="id" value="' . e($u['id']) . '">';
            input_label('Nome','name',$u['name'],'required maxlength="120"'); input_label('E-mail','email',$u['email'],'required maxlength="190"','email');
            echo '<label>Perfil<select name="role"><option value="editor"' . ($u['role']==='editor'?' selected':'') . '>Editor</option><option value="admin"' . ($u['role']==='admin'?' selected':'') . '>Administrador</option></select></label>';
            input_label($edit?'Nova senha (opcional)':'Senha (mínimo 12 caracteres)','password','','minlength="12" autocomplete="new-password"','password');
            if ($edit) echo '<label class="active-field"><input type="checkbox" name="active" value="1"' . ((int)$u['active']?' checked':'') . '> Conta ativa</label>';
            echo '<button class="primary-button" type="submit">SALVAR USUÁRIO</button></form></div>';
        }
        echo '<div class="admin-user-list"><div class="admin-user-list-title"><strong>Equipe</strong><span>' . count($users) . ' usuário(s)</span></div>';
        foreach($users as $u) echo '<div class="admin-user-row"><div class="user-avatar">' . e(first_char($u['name'])) . '</div><div class="user-data"><strong>' . e($u['name']) . '</strong><span>' . e($u['email']) . ' · ' . e($u['role']==='admin'?'Administrador':'Editor') . '</span></div><span class="user-status ' . ((int)$u['active']?'is-active':'') . '">' . ((int)$u['active']?'Ativo':'Inativo') . '</span><div class="admin-actions"><a href="/admin/usuarios?edit=' . (int)$u['id'] . '">Editar</a>' . ((int)$u['id']!==(int)$admin['id']?'<form method="post" action="/admin/usuarios/alternar">'.csrf_field().'<input type="hidden" name="id" value="'.(int)$u['id'].'"><button>'.((int)$u['active']?'Desativar':'Ativar').'</button></form><form method="post" action="/admin/usuarios/excluir" onsubmit="return confirm(\'Excluir este usuário?\')">'.csrf_field().'<input type="hidden" name="id" value="'.(int)$u['id'].'"><button>Excluir</button></form>':'') . '</div></div>';
        echo '</div><a class="back-store" href="/admin">← Voltar ao painel</a></main>'; page_end(); exit;
    }
    http_response_code(404); page_start('Página não encontrada'); echo '<main class="admin-page"><h1>Página não encontrada</h1><a href="/admin">Voltar ao painel</a></main>'; page_end(); exit;
}

/* Public storefront routes. */
if ($path === '/') {
    page_start('Nossa história | Fenix-Fer Comércio de Ferro','Conheça a história da Fenix-Fer, construída desde 2019 com dedicação, confiança e parceria com nossos clientes.');
    echo '<main class="home-page"><section class="story-section"><div class="story-inner"><div class="story-panel"><div class="story-copy"><span class="eyebrow">FENIX-FER · DESDE 2019</span><h1>Nossa História</h1><div class="story-text">';
    echo '<p>Tudo começou em 2019, com um sonho: criar uma loja que pudesse oferecer produtos, soluções e, acima de tudo, um atendimento de qualidade para cada cliente.</p>';
    echo '<p>Desde o início, nossa missão sempre foi atender a todos da melhor forma possível, buscando entender as necessidades de cada pessoa e oferecer produtos e serviços que realmente façam a diferença.</p>';
    echo '<p>A nossa loja foi construída com muito trabalho, dedicação e sonhos. Cada detalhe que existe aqui representa um pouco da nossa história e de tudo aquilo que acreditamos.</p>';
    echo '<p>E se hoje esse sonho se tornou realidade, é graças a cada cliente que confiou em nosso trabalho, comprou conosco, indicou nossa loja e fez parte da nossa caminhada.</p>';
    echo '<p>Desde 2019, construímos muito mais do que uma loja: construímos relações, confiança e uma história junto com nossos clientes.</p>';
    echo '<p class="story-closing">E essa história continua. <span aria-label="coração">❤️</span></p></div><div class="story-signature"><span class="story-signature-mark">F</span><p><strong>Fenix Fer</strong><span>um sonho que se tornou realidade graças a você.</span></p></div><div class="story-actions"><a class="primary-button" href="/produtos">CONHEÇA NOSSOS PRODUTOS ' . icon_svg('arrow-right',15) . '</a><a class="story-contact-link" href="' . e(whatsapp_url('Olá, Fenix-Fer! Quero conhecer melhor a loja e seus produtos.')) . '" target="_blank" rel="noopener noreferrer">Fale com a nossa equipe ' . icon_svg('chat',15) . '</a></div></div>';
    echo '<aside class="story-aside"><div class="story-aside-orbit story-orbit-one"></div><div class="story-aside-orbit story-orbit-two"></div><span class="story-aside-label">UMA HISTÓRIA DE CONFIANÇA</span><strong class="story-year">2019</strong><span class="story-year-caption">O começo de tudo</span><div class="story-aside-rule"></div><p>Mais do que uma loja, uma caminhada construída junto com cada cliente.</p><div class="story-aside-bottom"><span class="story-aside-emblem">F</span><span>FENIX-FER<br><small>COMÉRCIO DE FERRO</small></span></div></aside></div></div></section></main>'; page_end(); exit;
}
if ($path === '/produtos') {
    $cats=get_categories(true); $selected=(array)($_GET['categoria']??[]); $sort=(string)($_GET['ordem']??'relevantes');
    $query=substr(trim((string)($_GET['q']??'')),0,100);
    $products=list_products(['active'=>true,'q'=>$query,'categories'=>$selected,'sort'=>match($sort){'menor'=>'price_asc','maior'=>'price_desc','recentes'=>'newest',default=>'relevant'}]);
    $categoryCounts=[]; foreach($pdo->query('SELECT category,COUNT(*) AS n FROM products WHERE active=1 GROUP BY category')->fetchAll() as $row)$categoryCounts[$row['category']]=(int)$row['n'];
    page_start('Produtos | Fenix-Fer Comércio de Ferro','Explore o catálogo de ferragens e materiais da Fenix-Fer. Filtre por categoria e peça seu orçamento pelo WhatsApp.');
    echo '<main class="main-container products-page"><div class="breadcrumb"><a href="/">Início</a> / Produtos</div><section class="catalog-section" id="catalogo"><div class="catalog-intro"><span class="eyebrow">CATÁLOGO FENIX-FER</span><h1>' . ($query!==''?'Resultados para “'.e($query).'”':'Produtos para sua obra') . '</h1><p>Encontre o que precisa e conte com a nossa equipe para montar seu orçamento.</p></div><div class="catalog-layout"><aside class="filters"><div class="filter-body"><h3>Filtrar por categoria</h3><form method="get" action="/produtos"><label class="catalog-search-label"><span>Buscar produto</span><input type="search" name="q" maxlength="100" value="' . e($query) . '" placeholder="Nome do produto…"></label><div class="filter-options">';
    foreach($cats as $c) echo '<label class="filter-option"><input type="checkbox" name="categoria[]" value="' . e($c['slug']) . '"' . (in_array($c['slug'],$selected,true)?' checked':'') . '><span>' . e($c['name']) . '</span><small>' . (int)($categoryCounts[$c['id']]??0) . '</small></label>';
    echo '</div><label class="filter-option filter-sort">Ordenar por <select name="ordem"><option value="relevantes"' . ($sort==='relevantes'?' selected':'') . '>Mais relevantes</option><option value="menor"' . ($sort==='menor'?' selected':'') . '>Menor preço</option><option value="maior"' . ($sort==='maior'?' selected':'') . '>Maior preço</option><option value="recentes"' . ($sort==='recentes'?' selected':'') . '>Mais recentes</option></select></label><button class="secondary-button catalog-filter-button" type="submit">APLICAR FILTROS</button><a class="clear-filters" href="/produtos">Limpar busca e filtros</a></form><div class="filter-contact"><span class="filter-contact-title">Atendimento Fenix-Fer</span><p>Quer ajuda para escolher?</p><a href="' . e(whatsapp_url('Olá, Fenix-Fer! Gostaria de ajuda para escolher produtos.')) . '" target="_blank" rel="noopener noreferrer">Fale com a gente pelo WhatsApp ' . icon_svg('arrow-right',13) . '</a></div></div></aside><div class="catalog-products"><div class="listing-toolbar"><span><strong>' . count($products) . '</strong> produto(s) encontrado(s)</span><a href="/categorias">Ver categorias ' . icon_svg('arrow-right',13) . '</a></div>';
    render_products($products); echo '</div></div></section></main>'; page_end(); exit;
}
if ($path === '/categorias') {
    $cats=get_categories(true); $products=list_products(['active'=>true]); page_start('Categorias de ferragens | Fenix-Fer','Explore categorias de fechaduras, parafusos, gonzos, colas, thinner, buchas e mais.'); echo '<main class="main-container"><div class="breadcrumb"><a href="/">Início</a> / Categorias</div>'; category_strip($cats); echo '<section class="catalog-section" id="catalogo"><div class="catalog-intro"><span class="eyebrow">CATÁLOGO FENIX-FER</span><h2>Todas as categorias</h2><p>Ferragens e materiais selecionados para cada etapa da sua obra.</p></div>'; render_products($products); echo '</section></main>'; page_end(); exit;
}
if ($path === '/ofertas') {
    $products=list_products(['active'=>true,'featured'=>true]); page_start('Ofertas | Fenix-Fer','Produtos em destaque da Fenix-Fer. Consulte ofertas e disponibilidade pelo WhatsApp.'); echo '<main class="main-container"><div class="breadcrumb"><a href="/">Início</a> / Ofertas</div><section class="catalog-section"><div class="catalog-intro"><span class="eyebrow">SELEÇÃO FENIX-FER</span><h2>Produtos em destaque</h2><p>Itens selecionados pela nossa equipe. Consulte valores e disponibilidade.</p></div>'; render_products($products); echo '</section></main>'; page_end(); exit;
}
if (preg_match('~^/produto/([^/]+)$~',$path,$m)) {
    $product=get_product(rawurldecode($m[1])); if (!$product) { http_response_code(404); page_start('Produto não encontrado'); echo '<main class="main-container simple-page"><div class="simple-panel"><h1>Produto não encontrado</h1><p>Esse item pode ter sido removido ou está indisponível.</p><a class="primary-button" href="/produtos">VOLTAR AO CATÁLOGO</a></div></main>'; page_end(); exit; }
    $related=list_products(['active'=>true,'limit'=>5]); $related=array_values(array_filter($related,fn($p)=>$p['id']!==$product['id'])); usort($related,fn($a,$b)=>(int)($b['category']===$product['category']) <=>(int)($a['category']===$product['category'])); $related=array_slice($related,0,4);
    page_start($product['name'].' | Fenix-Fer',substr(strip_tags($product['description'] ?: $product['specification']),0,160)); echo '<main class="main-container product-page"><div class="breadcrumb"><a href="/">Início</a> / <a href="/produtos?categoria%5B%5D=' . rawurlencode($product['category_slug']) . '#catalogo">' . e($product['category_name']) . '</a> / ' . e($product['name']) . '</div><div class="detail-layout"><div class="detail-image">' . image_or_placeholder(product_image_ref($product),$product['name']) . '</div><div class="detail-content"><span class="eyebrow">' . e(upper_utf8($product['category_name'])) . '</span><h1>' . e($product['name']) . '</h1><p class="detail-spec">' . e($product['specification'] ?: '—') . '</p><div class="detail-rule"></div><p class="detail-description">' . nl2br(e($product['description'] ?: 'Produto da categoria ' . $product['category_name'] . ' para sua obra e seus projetos.')) . '</p><div class="detail-spec-box"><strong>Especificações</strong><div><span>Categoria</span><b>' . e($product['category_name']) . '</b></div><div><span>Detalhe</span><b>' . e($product['specification'] ?: '—') . '</b></div>' . ((int)$product['featured']?'<div><span>Destaque</span><b>Sim</b></div>':'') . '</div><div class="detail-price"><small>Valor de referência</small><strong>' . e(money($product['price_in_cents']===null?null:(int)$product['price_in_cents'])) . '</strong><span>Consulte disponibilidade e valor final com nossa equipe.</span></div><form class="detail-actions" method="post" action="/carrinho/adicionar" data-cart-add>' . csrf_field() . '<input type="hidden" name="product_id" value="' . e($product['id']) . '"><input type="hidden" name="return_to" value="/produto/' . e($product['slug']) . '"><div class="qty-control"><button type="button" aria-label="Diminuir quantidade" onclick="this.nextElementSibling.stepDown()">' . icon_svg('minus',14) . '</button><input type="number" name="quantity" min="1" max="99" value="1" aria-label="Quantidade"><button type="button" aria-label="Aumentar quantidade" onclick="this.previousElementSibling.stepUp()">' . icon_svg('plus',14) . '</button></div><button class="primary-button" type="submit">' . icon_svg('cart',17) . ' ADICIONAR AO CARRINHO</button></form><a class="secondary-button detail-quote" href="' . e(whatsapp_url('Olá, Fenix-Fer! Gostaria de solicitar um orçamento para 1x ' . $product['name'] . ' | ' . ($product['specification'] ?: '—') . '. Aguardo disponibilidade, valores e prazo. Obrigado!')) . '" target="_blank" rel="noopener noreferrer">PEDIR ORÇAMENTO NO WHATSAPP</a><p class="detail-assurance">' . icon_svg('check',15) . ' Atendimento direto com nossa equipe</p></div></div>';
    if ($related) { echo '<section class="related-section"><div class="related-heading"><h2>Você também pode precisar</h2><a href="/produtos">Ver catálogo →</a></div><div class="products-grid">'; foreach($related as $p)product_card($p); echo '</div></section>'; } echo '</main>'; page_end(); exit;
}
if ($path === '/carrinho') {
    $items=cart_items(); $count=array_sum(array_column($items,'quantity')); page_start('Meu carrinho | Fenix-Fer','Revise os produtos antes de solicitar um orçamento.'); echo '<main class="main-container cart-page"><div class="breadcrumb"><a href="/">Início</a> / Carrinho</div><div class="page-heading"><span class="eyebrow">SEU PEDIDO</span><h1>Meu carrinho</h1><p>Revise os produtos antes de solicitar seu orçamento.</p></div>';
    if (!$items) echo '<div class="cart-empty"><h2>Seu carrinho está vazio</h2><p>Explore nosso catálogo e encontre o que precisa para a sua obra.</p><a href="/produtos" class="primary-button">VER PRODUTOS</a></div>';
    else { echo '<div class="cart-layout"><div class="cart-items"><div class="cart-items-head"><strong>Produtos (' . $count . ')</strong><form method="post" action="/carrinho/limpar" onsubmit="return confirm(\'Limpar o carrinho?\')">' . csrf_field() . '<button type="submit">Limpar carrinho</button></form></div>';
        foreach($items as $item) { $p=$item['product']; echo '<div class="cart-item"><a href="/produto/' . rawurlencode($p['slug']) . '" class="cart-thumbnail">' . image_or_placeholder(product_image_ref($p),$p['name']) . '</a><div class="cart-item-main"><span class="product-category">' . e($p['category_name']) . '</span><a href="/produto/' . rawurlencode($p['slug']) . '" class="cart-item-title">' . e($p['name']) . '</a><span class="cart-item-spec">' . e($p['specification'] ?: '—') . '</span><strong class="cart-item-price">' . e(money($p['price_in_cents']===null?null:(int)$p['price_in_cents'])) . '</strong></div><div class="cart-item-controls"><form method="post" action="/carrinho/atualizar">' . csrf_field() . '<div class="qty-control"><button type="button" aria-label="Diminuir quantidade" onclick="this.nextElementSibling.stepDown()">' . icon_svg('minus',14) . '</button><input type="number" min="1" max="99" value="' . $item['quantity'] . '" name="quantity[' . e($p['id']) . ']" aria-label="Quantidade"><button type="button" aria-label="Aumentar quantidade" onclick="this.previousElementSibling.stepUp()">' . icon_svg('plus',14) . '</button></div><button type="submit">' . icon_svg('check',13) . ' Atualizar</button></form><form method="post" action="/carrinho/remover">' . csrf_field() . '<input type="hidden" name="product_id" value="' . e($p['id']) . '"><button class="remove-item" type="submit">' . icon_svg('trash',14) . ' Remover</button></form></div></div>'; }
        echo '</div><aside class="cart-summary"><h2>Resumo do pedido</h2><div><span>Quantidade de itens</span><strong>' . $count . '</strong></div><div><span>Valores</span><strong>Sob consulta</strong></div><p>Os valores e a disponibilidade serão confirmados pela nossa equipe no WhatsApp.</p><a class="primary-button" href="/checkout">FINALIZAR PELO WHATSAPP</a><a class="continue-link" href="/produtos">← CONTINUAR COMPRANDO</a></aside></div>'; }
    echo '</main>'; page_end(); exit;
}
if ($path === '/checkout') {
    $items=cart_items(); $count=array_sum(array_column($items,'quantity')); page_start('Solicitar orçamento | Fenix-Fer','Envie sua solicitação de orçamento pelo WhatsApp.'); echo '<main class="main-container checkout-page"><div class="breadcrumb"><a href="/">Início</a> / <a href="/carrinho">Carrinho</a> / Orçamento</div><div class="page-heading"><span class="eyebrow">QUASE LÁ</span><h1>Solicitar orçamento</h1><p>Confira os produtos e envie a solicitação para nossa equipe pelo WhatsApp.</p></div>';
    if (!$items) echo '<div class="cart-empty"><h2>Não há produtos para solicitar</h2><p>Adicione produtos ao carrinho antes de continuar.</p><a class="primary-button" href="/produtos">VER CATÁLOGO</a></div>';
    else { echo '<div class="checkout-layout"><div class="checkout-list"><h2>Itens selecionados</h2>'; foreach($items as $item){$p=$item['product'];echo '<div class="checkout-line"><div class="checkout-thumb">' . image_or_placeholder(product_image_ref($p),$p['name']) . '</div><div><strong>' . e($p['name']) . '</strong><span>' . e($p['specification'] ?: '—') . '</span></div><b>' . $item['quantity'] . 'x</b></div>'; } echo '</div><aside class="checkout-summary"><h2>Seu orçamento</h2><p>Ao clicar no botão abaixo, o WhatsApp abrirá com a lista dos seus produtos já preenchida. Nossa equipe confirmará valores, disponibilidade e prazo.</p><div><span>Itens</span><strong>' . $count . '</strong></div><div><span>Total</span><strong>Sob consulta</strong></div><a href="' . e(whatsapp_url(quote_message($items))) . '" target="_blank" rel="noopener noreferrer" class="primary-button">ABRIR WHATSAPP</a><a href="/carrinho" class="continue-link">← VOLTAR AO CARRINHO</a></aside></div>'; }
    echo '</main>'; page_end(); exit;
}
if ($path === '/conta') {
    page_start('Atendimento e minha conta | Fenix-Fer','Fale diretamente com a Fenix-Fer e solicite seu orçamento de ferragens pelo WhatsApp.'); echo '<main class="main-container simple-page"><div class="breadcrumb"><a href="/">Início</a> / Minha conta</div><div class="simple-panel"><span class="eyebrow">ATENDIMENTO PERSONALIZADO</span><h1>Estamos aqui para ajudar.</h1><p>Ainda não oferecemos acesso a uma conta online. Para consultar seus pedidos, disponibilidade ou solicitar um orçamento, fale com nossa equipe diretamente pelo WhatsApp.</p><div class="simple-actions"><a class="primary-button" href="' . e(whatsapp_url('Olá, Fenix-Fer! Gostaria de falar com a equipe.')) . '" target="_blank" rel="noopener noreferrer">FALAR NO WHATSAPP</a><a class="secondary-button" href="/carrinho">VER CARRINHO</a></div></div></main>'; page_end(); exit;
}
if ($path === '/robots.txt') { header('Content-Type: text/plain; charset=utf-8'); echo "User-agent: *\nAllow: /\nDisallow: /admin\nSitemap: " . e((!empty($_SERVER['HTTPS'])?'https':'http') . '://' . ($_SERVER['HTTP_HOST']??'localhost') . '/sitemap.xml') . "\n"; exit; }
if ($path === '/sitemap.xml') {
    header('Content-Type: application/xml; charset=utf-8'); $origin=(!empty($_SERVER['HTTPS'])?'https':'http').'://'.($_SERVER['HTTP_HOST']??'localhost'); echo '<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
    foreach(['/','/categorias','/ofertas'] as $url) echo '<url><loc>' . e($origin.$url) . '</loc></url>';
    foreach(list_products(['active'=>true]) as $p) echo '<url><loc>' . e($origin.'/produto/'.$p['slug']) . '</loc></url>';
    echo '</urlset>'; exit;
}
http_response_code(404); page_start('Página não encontrada'); echo '<main class="main-container simple-page"><div class="simple-panel"><span class="eyebrow">ERRO 404</span><h1>Essa página não foi encontrada.</h1><p>Volte ao catálogo para explorar os produtos.</p><a class="primary-button" href="/">IR PARA O INÍCIO</a></div></main>'; page_end();
