<?php
declare(strict_types=1);

const PRODUCT_IMAGE_MAX_BYTES = 5_242_880;
const PRODUCT_IMAGE_MAX_PIXELS = 40_000_000;

function e(mixed $value): string { return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function h(string $name, string $default = ''): string { return e($_POST[$name] ?? $_GET[$name] ?? $default); }
function now_iso(): string { return gmdate('Y-m-d\\TH:i:s.v\\Z'); }
function first_char(string $text): string { return preg_match('/^./us', $text, $m) ? $m[0] : ''; }
function upper_utf8(string $text): string { return strtoupper(strtr($text, ['á'=>'Á','à'=>'À','â'=>'Â','ã'=>'Ã','ä'=>'Ä','é'=>'É','ê'=>'Ê','ë'=>'Ë','í'=>'Í','ï'=>'Ï','ó'=>'Ó','ô'=>'Ô','õ'=>'Õ','ö'=>'Ö','ú'=>'Ú','ü'=>'Ü','ç'=>'Ç'])); }
function new_id(): string { return bin2hex(random_bytes(8)); }
function slugify(string $text): string
{
    $text = trim($text);
    $ascii = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $text);
    $text = strtolower($ascii === false ? $text : $ascii);
    $text = preg_replace('/[^a-z0-9]+/', '-', $text) ?? '';
    return trim($text, '-');
}
function money(?int $cents): string { return $cents === null ? 'Consulte o preço' : 'R$ ' . number_format($cents / 100, 2, ',', '.'); }
function whatsapp_number(): string
{
    $configured = trim((string)(getenv('FENIX_WHATSAPP_NUMBER') ?: ''));
    if ($configured !== '') return preg_replace('/\\D+/', '', $configured) ?? '';
    try {
        $stmt = db()->prepare("SELECT setting_value FROM app_settings WHERE setting_key='whatsapp_number'");
        $stmt->execute();
        return preg_replace('/\\D+/', '', (string)($stmt->fetchColumn() ?: '')) ?? '';
    } catch (Throwable) { return ''; }
}
function save_app_setting(string $key, string $value): void
{
    $pdo=db();
    $sql=$pdo->getAttribute(PDO::ATTR_DRIVER_NAME)==='mysql'
        ? 'INSERT INTO app_settings(setting_key,setting_value,updated_at) VALUES(:key,:value,:updated) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value),updated_at=VALUES(updated_at)'
        : 'INSERT INTO app_settings(setting_key,setting_value,updated_at) VALUES(:key,:value,:updated) ON CONFLICT(setting_key) DO UPDATE SET setting_value=excluded.setting_value,updated_at=excluded.updated_at';
    $pdo->prepare($sql)->execute([':key'=>$key,':value'=>$value,':updated'=>now_iso()]);
}
function whatsapp_url(string $message): string
{
    $number = whatsapp_number();
    return 'https://wa.me/' . $number . '?text=' . rawurlencode($message);
}

/** SVGs locais em traço para evitar símbolos de fonte inconsistentes. */
function icon_svg(string $name, int $size = 18, string $class = ''): string
{
    $paths = [
        'search'=>'<circle cx="11" cy="11" r="7.25"/><path d="m16.5 16.5 4 4"/>',
        'user'=>'<circle cx="12" cy="8" r="3.5"/><path d="M5 20a7 7 0 0 1 14 0"/>',
        'chat'=>'<path d="M20 11.5a7.5 7.5 0 0 1-8 7.5 8.7 8.7 0 0 1-3.6-.8L4 20l1.2-3.4A7.1 7.1 0 0 1 4 12c0-4.1 3.6-7.5 8-7.5s8 3.1 8 7Z"/>',
        'cart'=>'<path d="M3 4h2l2.1 11.1a2 2 0 0 0 2 1.6h8.7a2 2 0 0 0 1.9-1.5L21 8H6"/><circle cx="10" cy="20" r="1"/><circle cx="18" cy="20" r="1"/>',
        'menu'=>'<path d="M4 7h16M4 12h16M4 17h16"/>',
        'grid'=>'<rect x="4" y="4" width="6" height="6" rx="1"/><rect x="14" y="4" width="6" height="6" rx="1"/><rect x="4" y="14" width="6" height="6" rx="1"/><rect x="14" y="14" width="6" height="6" rx="1"/>',
        'package'=>'<path d="m12 3 8 4.3v9.4L12 21l-8-4.3V7.3L12 3Z"/><path d="m4.4 7.5 7.6 4 7.6-4M12 12v9M8 5.1l8 4.2"/>',
        'key'=>'<circle cx="8" cy="15" r="4"/><path d="m11 12 8-8 2 2-2 2 2 2-3 3-2-2-2 2"/>',
        'bolt'=>'<path d="M13 2 4.5 13h6L10 22l9.5-12h-6L13 2Z"/>',
        'tool'=>'<path d="M14 6a5 5 0 0 0-6.4 6.4L3 17l4 4 4.6-4.6A5 5 0 0 0 18 10l-3 3-4-4 3-3Z"/><path d="m14 6 4-4 4 4-4 4"/>',
        'drop'=>'<path d="M12 3s6.5 7 6.5 11.5a6.5 6.5 0 0 1-13 0C5.5 10 12 3 12 3Z"/><path d="M9 16a3 3 0 0 0 3 2"/>',
        'flask'=>'<path d="M9 3h6M10 3v6l-5.5 9.2A2.5 2.5 0 0 0 6.6 22h10.8a2.5 2.5 0 0 0 2.1-3.8L14 9V3"/><path d="M7.5 16h9"/>',
        'anchor'=>'<circle cx="12" cy="5" r="2.5"/><path d="M12 8v13M5 13H2l2 3a9 9 0 0 0 16 0l2-3h-3M8 12h8"/>',
        'check'=>'<path d="m5 12 4.5 4.5L19 7"/>',
        'plus'=>'<path d="M12 5v14M5 12h14"/>',
        'minus'=>'<path d="M5 12h14"/>',
        'trash'=>'<path d="M4 7h16M10 11v6M14 11v6M5.5 7l1 14h11l1-14M9 7V4h6v3"/>',
        'edit'=>'<path d="M12 20h9"/><path d="m16.5 3.5 4 4L9 19l-5 1 1-5 11.5-11.5Z"/>',
        'arrow-right'=>'<path d="M4 12h15M13 5l7 7-7 7"/>',
        'arrow-down'=>'<path d="M12 4v15M5 13l7 7 7-7"/>',
        'arrow-up-right'=>'<path d="M7 17 17 7M8 7h9v9"/>',
        'logout'=>'<path d="M10 17l5-5-5-5M15 12H3"/><path d="M12 3h6a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-6"/>',
        'image'=>'<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="8.5" cy="9" r="1.5"/><path d="m21 15-5-5L5 20"/>',
        'users'=>'<path d="M16 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="10" cy="7" r="4"/><path d="M20 21v-2a4 4 0 0 0-3-3.9M16 3.2a4 4 0 0 1 0 7.6"/>',
        'tag'=>'<path d="M20.6 13.4 13.4 20.6a2 2 0 0 1-2.8 0L3 13V3h10l7.6 7.6a2 2 0 0 1 0 2.8Z"/><circle cx="7.5" cy="7.5" r="1"/>',
        'info'=>'<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>',
        'star'=>'<path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-3-5.6 3 1.1-6.2L3 9.6l6.2-.9L12 3Z"/>',
        'home'=>'<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-6v-7h-4v7H4a1 1 0 0 1-1-1V10Z"/>',
    ];
    $svg = $paths[$name] ?? $paths['package'];
    $size = max(12, min(64, $size));
    return '<svg class="' . e($class) . '" width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' . $svg . '</svg>';
}
function category_icon_name(string $name): string
{
    $ascii = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $name);
    $name = strtolower($ascii === false ? $name : $ascii);
    return match (true) {
        str_contains($name, 'fechadura') => 'key',
        str_contains($name, 'parafuso') => 'bolt',
        str_contains($name, 'gonzo') => 'tool',
        str_contains($name, 'cola') => 'drop',
        str_contains($name, 'thinner') => 'flask',
        str_contains($name, 'bucha') => 'anchor',
        default => 'package',
    };
}
function csrf_token(): string
{
    if (empty($_SESSION['_csrf'])) $_SESSION['_csrf'] = bin2hex(random_bytes(32));
    return (string)$_SESSION['_csrf'];
}
function csrf_field(): string { return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">'; }
function is_ajax_cart_request(): bool
{
    return str_starts_with((string)(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/'), '/carrinho/')
        && (str_contains(strtolower((string)($_SERVER['HTTP_ACCEPT'] ?? '')), 'application/json')
            || strtolower((string)($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '')) === 'xmlhttprequest');
}
function verify_csrf(): void
{
    $sent = (string)($_POST['_csrf'] ?? '');
    if ($sent === '' || !hash_equals(csrf_token(), $sent)) {
        http_response_code(419);
        if (is_ajax_cart_request()) { header('Content-Type: application/json; charset=utf-8'); echo json_encode(['ok'=>false,'message'=>'Sua sessão expirou. Atualize a página e tente novamente.']); }
        else echo 'Sessão expirada. Volte e tente novamente.';
        exit;
    }
}
function redirect(string $to): never { header('Location: ' . $to, true, 303); exit; }
function flash(string $type, string $message): void { $_SESSION['_flash'] = ['type'=>$type,'message'=>$message]; }
function take_flash(): ?array { $f = $_SESSION['_flash'] ?? null; unset($_SESSION['_flash']); return is_array($f) ? $f : null; }
function current_user(): ?array
{
    $id = $_SESSION['staff_id'] ?? null;
    if (!$id) return null;
    $q = db()->prepare('SELECT id,name,email,role,active FROM staff WHERE id=:id');
    $q->execute([':id'=>$id]);
    $user = $q->fetch();
    if (!$user || !(int)$user['active']) { unset($_SESSION['staff_id']); return null; }
    return $user;
}
function require_staff(bool $adminOnly = false): array
{
    $user = current_user();
    if (!$user) redirect('/admin/login');
    if ($adminOnly && $user['role'] !== 'admin') { http_response_code(403); exit('Acesso permitido somente a administradores.'); }
    return $user;
}
function is_admin(): bool { return (current_user()['role'] ?? '') === 'admin'; }
function cart_count(): int { return array_sum(array_map(static fn($n)=>max(0,min(99,(int)$n)), $_SESSION['cart'] ?? [])); }
function cart_items(): array
{
    $cart = $_SESSION['cart'] ?? [];
    if (!$cart) return [];
    $ids = array_keys($cart);
    $marks = implode(',', array_fill(0, count($ids), '?'));
    $q = db()->prepare("SELECT p.*, c.name AS category_name, c.slug AS category_slug FROM products p JOIN categories c ON c.id=p.category WHERE p.id IN ($marks) AND p.active=1 AND c.active=1");
    $q->execute($ids);
    $found = [];
    foreach ($q->fetchAll() as $product) {
        $qty = max(1, min(99, (int)($cart[$product['id']] ?? 1)));
        $found[] = ['product'=>$product,'quantity'=>$qty];
    }
    return $found;
}
function quote_message(array $items): string
{
    $lines = [];
    foreach ($items as $item) {
        $p = $item['product'];
        $price = $p['price_in_cents'] === null ? '' : ' · ' . money((int)$p['price_in_cents']);
        $lines[] = '- ' . $item['quantity'] . 'x ' . $p['name'] . "\\n  Categoria: " . ($p['category_name'] ?: '—') . "\\n  Especificação: " . ($p['specification'] ?: '—') . $price;
    }
    return "Olá, Fenix-Fer! Gostaria de solicitar um orçamento para:\\n\\n" . implode("\\n", $lines) . "\\n\\nAguardo disponibilidade, valores e prazo. Obrigado!";
}
function product_image_ref(array $product): string
{
    $key = (string)($product['image_path'] ?? '');
    if ($key !== '' && preg_match('/^[a-f0-9]{40}\\.(?:jpg|png|webp)$/', $key)) return '/media/products/' . rawurlencode($key);
    $legacy = (string)($product['image_url'] ?? '');
    return preg_match('~^https?://~i', $legacy) ? $legacy : '';
}
function image_or_placeholder(?string $url, string $alt, string $class = ''): string
{
    $src = '';
    if ($url && (preg_match('~^https?://~i', $url) || preg_match('~^/media/products/[a-f0-9]{40}\\.(?:jpg|png|webp)$~', $url))) $src = $url;
    if ($src !== '') return '<img class="' . e($class) . '" src="' . e($src) . '" alt="' . e($alt) . '" loading="lazy">';
    return '<span class="image-placeholder" aria-hidden="true">' . icon_svg('image', 32) . '</span>';
}
function save_uploaded_product_image(array $file): ?string
{
    $error = (int)($file['error'] ?? UPLOAD_ERR_NO_FILE);
    if ($error === UPLOAD_ERR_NO_FILE) return null;
    if ($error !== UPLOAD_ERR_OK) {
        $message = match ($error) {
            UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => 'A imagem excede o limite de envio do servidor.',
            UPLOAD_ERR_PARTIAL => 'O envio da imagem foi interrompido. Tente novamente.',
            default => 'Não foi possível receber a imagem. Tente novamente.',
        };
        throw new RuntimeException($message);
    }
    $tmp = (string)($file['tmp_name'] ?? '');
    $bytes = (int)($file['size'] ?? 0);
    if (!is_uploaded_file($tmp) || $bytes < 1 || $bytes > PRODUCT_IMAGE_MAX_BYTES) throw new RuntimeException('Escolha uma imagem de até 5 MB.');
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($tmp);
    $allowed = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
    if (!isset($allowed[$mime])) throw new RuntimeException('Formato não aceito. Use JPG, PNG ou WebP.');
    $dimensions = @getimagesize($tmp);
    if (!$dimensions || ($dimensions['mime'] ?? '') !== $mime) throw new RuntimeException('O arquivo não parece ser uma imagem válida.');
    $width = (int)$dimensions[0]; $height = (int)$dimensions[1];
    if ($width < 1 || $height < 1 || $width > 10000 || $height > 10000 || $width * $height > PRODUCT_IMAGE_MAX_PIXELS) throw new RuntimeException('A imagem tem dimensões muito grandes. Reduza-a antes de enviar.');
    $directory = APP_ROOT . '/storage/uploads/products';
    if (!is_dir($directory) && !mkdir($directory, 0750, true) && !is_dir($directory)) throw new RuntimeException('Não foi possível preparar o armazenamento de imagens.');
    $key = bin2hex(random_bytes(20)) . '.' . $allowed[$mime];
    $destination = $directory . '/' . $key;
    if (!move_uploaded_file($tmp, $destination)) throw new RuntimeException('Não foi possível salvar a imagem enviada.');
    chmod($destination, 0640);
    return $key;
}
function delete_product_image_if_unused(?string $key): void
{
    if (!$key || !preg_match('/^[a-f0-9]{40}\\.(?:jpg|png|webp)$/', $key)) return;
    $q = db()->prepare('SELECT COUNT(*) FROM products WHERE image_path=:path');
    $q->execute([':path'=>$key]);
    if ((int)$q->fetchColumn() !== 0) return;
    $file = APP_ROOT . '/storage/uploads/products/' . $key;
    if (is_file($file) && !is_link($file)) @unlink($file);
}
function discard_new_product_image(?string $key): void
{
    if (!$key || !preg_match('/^[a-f0-9]{40}\\.(?:jpg|png|webp)$/', $key)) return;
    $file = APP_ROOT . '/storage/uploads/products/' . $key;
    if (is_file($file) && !is_link($file)) @unlink($file);
}
