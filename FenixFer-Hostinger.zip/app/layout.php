<?php
declare(strict_types=1);

function page_start(string $title, string $description = ''): void
{
    $flash = take_flash();
    $count = cart_count();
    $title = $title ? $title . ' | Fenix-Fer' : 'Fenix-Fer Comércio de Ferro';
    echo '<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">';
    echo '<title>' . e($title) . '</title><meta name="description" content="' . e($description ?: 'Ferragens e materiais para construção. Consulte nosso catálogo e peça seu orçamento pelo WhatsApp.') . '">';
    echo '<link rel="stylesheet" href="/assets/style.css"><link rel="stylesheet" href="/assets/php-overrides.css"><link rel="stylesheet" href="/assets/brand-refresh.css"><link rel="stylesheet" href="/assets/cart-icons.css"><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@600;700;800&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet"></head><body>';
    echo '<header class="site-header"><div class="header-inner"><a class="brand" href="/" aria-label="Fenix-Fer — início"><img src="https://images.hostinger.com/ca17eb7a-74a2-4415-8031-afbe3e9d96dd.png" alt="Fenix-Fer Comércio de Ferro"></a>';
    echo '<nav class="desktop-nav"><a href="/">Sobre nós</a><a href="/produtos">Produtos</a><a href="/categorias">Categorias</a><a href="/ofertas">Ofertas</a></nav>';
    echo '<form class="header-search" method="get" action="/produtos"><input name="q" value="' . e((string)($_GET['q'] ?? '')) . '" placeholder="O que você procura?" aria-label="Buscar produtos"><button aria-label="Buscar" type="submit">' . icon_svg('search', 19) . '</button></form>';
    echo '<div class="header-actions"><a class="account-link" href="/conta">' . icon_svg('user', 17) . '<span>Minha conta</span></a><a class="whatsapp-header" href="' . e(whatsapp_url('Olá, Fenix-Fer! Gostaria de falar com a equipe sobre ferragens e materiais para construção.')) . '" target="_blank" rel="noopener noreferrer">' . icon_svg('chat', 16) . '<span>FALAR NO WHATSAPP</span></a><a href="/carrinho" class="cart-link" aria-label="Carrinho: ' . $count . ' itens">' . icon_svg('cart', 23) . '<span class="cart-badge" aria-live="polite">' . $count . '</span></a><button class="mobile-icon menu-toggle" type="button" aria-label="Abrir menu" aria-expanded="false" onclick="const n=document.getElementById(\'mobile-nav\');const o=n.classList.toggle(\'nav-open\');this.setAttribute(\'aria-expanded\',o)">' . icon_svg('menu', 22) . '</button></div></div>';
    echo '<nav id="mobile-nav" class="mobile-nav"><a href="/">' . icon_svg('info',16) . ' Sobre nós</a><a href="/produtos">' . icon_svg('package',16) . ' Produtos</a><a href="/categorias">' . icon_svg('grid',16) . ' Categorias</a><a href="/ofertas">' . icon_svg('star',16) . ' Ofertas</a><a href="/conta">' . icon_svg('user', 16) . ' Minha conta</a><a href="/carrinho">' . icon_svg('cart', 16) . ' Meu carrinho <span class="mobile-cart-count">' . $count . '</span></a><form class="mobile-search" method="get" action="/produtos"><input name="q" placeholder="O que você procura?" aria-label="Buscar produtos"><button aria-label="Buscar" type="submit">' . icon_svg('search', 18) . '</button></form></nav></header><div class="metal-bar"></div>';
    if ($flash) echo '<div class="notice ' . e($flash['type']) . '" role="status">' . e($flash['message']) . '</div>';
}
function page_end(): void
{
    echo '<section class="help-banner"><div><span class="eyebrow">ATENDIMENTO FENIX-FER</span><h2>Precisando de ajuda para escolher?</h2><p>Fale com nossa equipe. Vamos ajudar você a encontrar o produto ideal e montar seu orçamento.</p></div><a class="primary-button" href="' . e(whatsapp_url('Olá, Fenix-Fer! Preciso de ajuda para escolher produtos para minha obra.')) . '" target="_blank" rel="noopener noreferrer">' . icon_svg('chat', 17) . ' FALAR NO WHATSAPP</a></section>';
    echo '<footer class="site-footer"><div class="footer-inner"><div class="footer-brand"><strong>FENIX-FER</strong><span>COMÉRCIO DE FERRO</span><p>Ferragens e materiais selecionados para cada etapa da sua obra.</p></div><div><h3>LOJA</h3><p><a href="/">Sobre nós</a><br><a href="/produtos">Produtos</a><br><a href="/categorias">Categorias</a><br><a href="/ofertas">Ofertas</a></p></div><div><h3>ATENDIMENTO</h3><p>Solicite seu orçamento direto com nossa equipe pelo WhatsApp.</p><p><a href="' . e(whatsapp_url('Olá, Fenix-Fer!')) . '" target="_blank" rel="noopener noreferrer">Fale conosco ' . icon_svg('arrow-right', 14) . '</a></p></div><div><h3>MINHA CONTA</h3><p><a href="/conta">Atendimento e pedidos</a><br><a href="/carrinho">Meu carrinho</a></p></div><div><h3>PAINEL</h3><p><a href="/admin/login">Acesso da equipe</a></p></div></div><div class="footer-bottom"><span>© ' . date('Y') . ' Fenix-Fer Comércio de Ferro</span><span>Orçamento pelo WhatsApp · Consulte disponibilidade</span></div></footer>';
    echo '<div class="toast-region" id="toast-region" aria-live="polite" aria-atomic="false"></div>';
    echo <<<'JS'
<script>
(function(){
  const region=document.getElementById('toast-region');
  function toast(message,kind){
    if(!region)return;
    const box=document.createElement('div');box.className='site-toast '+(kind||'success');box.setAttribute('role',kind==='error'?'alert':'status');
    const icon=document.createElement('span');icon.className='toast-mark';icon.innerHTML=kind==='error'?'<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M12 8v5m0 4h.01"/><circle cx="12" cy="12" r="9"/></svg>':'<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><path d="m5 12 4 4L19 6"/></svg>';
    const text=document.createElement('span');text.className='toast-message';text.textContent=message;
    box.append(icon,text);
    if(kind!=='error'){const link=document.createElement('a');link.href='/carrinho';link.className='toast-cart-link';link.textContent='Ver carrinho';box.append(link);}
    const close=document.createElement('button');close.type='button';close.className='toast-close';close.setAttribute('aria-label','Fechar notificação');close.textContent='×';close.addEventListener('click',()=>box.remove());box.append(close);
    region.append(box);window.setTimeout(()=>{box.classList.add('is-leaving');window.setTimeout(()=>box.remove(),250)},5200);
  }
  document.addEventListener('change',function(event){
    const input=event.target;if(!input.matches('input[type="file"][data-product-image]'))return;
    const file=input.files&&input.files[0];if(!file)return;
    if(file.size>5242880){input.value='';toast('A imagem deve ter no máximo 5 MB.','error');return;}
    const target=input.closest('form')?.querySelector('[data-image-preview]');if(!target)return;
    const url=URL.createObjectURL(file);target.replaceChildren();const image=document.createElement('img');image.src=url;image.alt='Prévia da imagem selecionada';
    image.onload=()=>URL.revokeObjectURL(url);image.onerror=()=>{URL.revokeObjectURL(url);target.textContent='Não foi possível mostrar a prévia';};target.append(image);
  });
  document.addEventListener('submit',async function(event){
    const form=event.target.closest('form[data-cart-add]');if(!form)return;
    event.preventDefault();if(form.dataset.busy==='1')return;form.dataset.busy='1';
    const button=form.querySelector('button[type="submit"]');const previous=button?button.innerHTML:'';
    if(button){button.disabled=true;button.setAttribute('aria-busy','true');button.innerHTML='<span class="button-spinner" aria-hidden="true"></span> ADICIONANDO…';}
    try{
      const response=await fetch(form.action,{method:'POST',body:new FormData(form),credentials:'same-origin',headers:{'Accept':'application/json','X-Requested-With':'XMLHttpRequest'}});
      let payload={};try{payload=await response.json()}catch(_){throw new Error('Não foi possível confirmar a inclusão. Atualize a página e tente novamente.')}
      if(!response.ok||!payload.ok)throw new Error(payload.message||'Não foi possível adicionar este produto.');
      document.querySelectorAll('.cart-badge').forEach(el=>el.textContent=String(payload.cart_count));
      document.querySelectorAll('.mobile-cart-count').forEach(el=>el.textContent=String(payload.cart_count));
      const cart=document.querySelector('.cart-link');if(cart)cart.setAttribute('aria-label','Carrinho: '+payload.cart_count+' itens');
      toast(payload.message||'Produto adicionado ao carrinho.','success');
    }catch(error){toast(error.message||'Falha ao adicionar produto. Tente novamente.','error');}
    finally{form.dataset.busy='0';if(button){button.disabled=false;button.removeAttribute('aria-busy');button.innerHTML=previous;}}
  });
  document.addEventListener('click',function(event){const nav=document.getElementById('mobile-nav');if(nav&&nav.classList.contains('nav-open')&&!nav.contains(event.target)&&!event.target.closest('.menu-toggle')){nav.classList.remove('nav-open');document.querySelector('.menu-toggle')?.setAttribute('aria-expanded','false')}});
})();
</script></body></html>
JS;
}
function product_card(array $p): void
{
    $returnTo = (string)($_SERVER['REQUEST_URI'] ?? '/');
    echo '<article class="product-card"><a class="product-image" href="/produto/' . rawurlencode($p['slug']) . '">' . image_or_placeholder(product_image_ref($p), $p['name']) . '</a><div class="product-info"><span class="product-category">' . e($p['category_name'] ?? 'FERRAGENS') . '</span><a class="product-title" href="/produto/' . rawurlencode($p['slug']) . '">' . e($p['name']) . '</a><p class="product-spec">' . e($p['specification'] ?: '—') . '</p><div class="product-bottom"><strong class="product-price">' . e(money($p['price_in_cents'] === null ? null : (int)$p['price_in_cents'])) . '</strong><span class="price-caption">Valor de referência</span></div><div class="product-actions"><form method="post" action="/carrinho/adicionar" data-cart-add>' . csrf_field() . '<input type="hidden" name="product_id" value="' . e($p['id']) . '"><input type="hidden" name="quantity" value="1"><input type="hidden" name="return_to" value="' . e($returnTo) . '"><button class="add-button" type="submit">' . icon_svg('plus', 15) . ' ADICIONAR AO CARRINHO</button></form><a class="quote-button" href="' . e(whatsapp_url('Olá, Fenix-Fer! Gostaria de solicitar orçamento para 1x ' . $p['name'] . ' | ' . ($p['specification'] ?: '—') . '.')) . '" target="_blank" rel="noopener noreferrer">' . icon_svg('chat', 14) . ' PEDIR ORÇAMENTO</a></div></div></article>';
}
function render_products(array $products): void
{
    if (!$products) { echo '<div class="empty-results"><h3>Nenhum produto encontrado</h3><p>Tente alterar a busca ou os filtros.</p><a class="primary-button" href="/produtos">VER TODOS OS PRODUTOS</a></div>'; return; }
    echo '<div class="products-grid">'; foreach ($products as $p) product_card($p); echo '</div>';
}
function category_strip(array $categories): void
{
    echo '<section class="categories-section"><div class="section-label"><span>ENCONTRE O QUE PRECISA</span><h2>Explore por categoria</h2></div><div class="categories-strip">';
    foreach ($categories as $category) {
        $visual = $category['image_url'] ? image_or_placeholder($category['image_url'], $category['name']) : icon_svg(category_icon_name($category['name']), 32, 'category-icon');
        echo '<a class="category-tile" href="/produtos?categoria%5B%5D=' . rawurlencode($category['slug']) . '#catalogo"><span class="category-visual">' . $visual . '</span><strong>' . e($category['name']) . '</strong></a>';
    }
    echo '</div></section>';
}
