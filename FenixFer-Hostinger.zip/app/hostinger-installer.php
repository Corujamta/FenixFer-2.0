<?php
declare(strict_types=1);

/** Intercepts the one-time MySQL setup before the normal front controller opens a DB connection. */
function handle_mysql_install_request(string $path, string $method): bool
{
    if ($path !== '/admin/install' || !in_array($method,['GET','POST'],true)) return false;
    $config=database_config();
    if (($config['driver']??'sqlite')!=='mysql' || database_is_configured()) return false;
    $tokenFile=APP_ROOT.'/storage/setup.token';
    $expected=is_file($tokenFile)?trim((string)file_get_contents($tokenFile)):'';
    $given=$method==='GET'?(string)($_GET['key']??''):(string)($_POST['key']??'');
    if ($expected==='' || strlen($given)!==strlen($expected) || !hash_equals($expected,$given)) {
        http_response_code(404); exit('Instalador indisponível.');
    }
    header('Cache-Control: no-store'); header('Referrer-Policy: no-referrer');
    if ($method==='POST') {
        $secureRequest=(!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off') || strtolower(trim((string)($_SERVER['HTTP_X_FORWARDED_PROTO']??'')))==='https';
        if (!$secureRequest) setup_failure('Ative o SSL do domínio e abra o instalador em HTTPS antes de enviar os dados do banco.', $given);
        verify_csrf();
        $name=post_string('name',120); $email=strtolower(post_string('email',190));
        $password=(string)($_POST['password']??''); $confirmation=(string)($_POST['password_confirm']??'');
        $phone=preg_replace('/\\D+/', '', post_string('whatsapp_number',32))??'';
        if ($name==='' || !filter_var($email,FILTER_VALIDATE_EMAIL)) setup_failure('Informe seu nome e um e-mail válido.', $given);
        if (strlen($password)<12) setup_failure('A senha deve ter pelo menos 12 caracteres.', $given);
        if (!hash_equals($password,$confirmation)) setup_failure('As senhas não são iguais.', $given);
        if ($phone!=='' && (strlen($phone)<10 || strlen($phone)>15)) setup_failure('Confira o WhatsApp com código do país e DDD, ou deixe vazio.', $given);
        $dbConfig=['host'=>post_string('db_host',255),'port'=>post_string('db_port',5) ?: '3306','database'=>post_string('db_name',64),'username'=>post_string('db_user',64),'password'=>(string)($_POST['db_password']??'')];
        try {
            save_mysql_database_config($dbConfig);
            $pdo=db();
            if ((int)$pdo->query('SELECT COUNT(*) FROM staff')->fetchColumn()!==0) throw new RuntimeException('Use um banco de dados novo e vazio.');
            $pdo->beginTransaction();
            try {
                $pdo->prepare('INSERT INTO staff(name,email,password_hash,role,active,created_at) VALUES(:name,:email,:hash,\'admin\',1,:created)')->execute([':name'=>$name,':email'=>$email,':hash'=>password_hash($password,PASSWORD_DEFAULT),':created'=>now_iso()]);
                save_app_setting('whatsapp_number',$phone);
                $pdo->commit();
            } catch(Throwable $error) { if($pdo->inTransaction())$pdo->rollBack(); throw $error; }
            @unlink($tokenFile);
            flash('success','Instalação concluída. Entre com sua conta de administrador.');
            redirect('/admin/login');
        } catch(Throwable $error) {
            @unlink(APP_ROOT.'/storage/db-config.php');
            if ($error instanceof RuntimeException && !($error instanceof DatabaseConfigurationRequired)) $message=$error->getMessage();
            elseif (!extension_loaded('pdo_mysql')) $message='Ative a extensão pdo_mysql no hPanel e tente novamente.';
            else $message='Não foi possível conectar ou preparar o banco. Confira os dados do MySQL e use um banco novo e vazio.';
            error_log('Fenix-Fer MySQL setup failed (' . get_class($error) . ', code ' . (string)$error->getCode() . ').');
            setup_failure($message,$given);
        }
    }
    $flash=take_flash();
    page_start('Instalação Hostinger — Fenix-Fer','Conecte o MySQL da hospedagem e crie o primeiro administrador.');
    if ($flash) echo '<div class="notice ' . e($flash['type']) . '" role="alert">' . e($flash['message']) . '</div>';
    echo '<main class="admin-login-page hostinger-install-page"><div class="admin-login-box hostinger-install-box"><div class="admin-login-icon">' . icon_svg('package',23) . '</div><span class="eyebrow">CONFIGURAÇÃO INICIAL · ETAPA ÚNICA</span><h1>Conecte sua loja</h1><p>Copie os dados do banco MySQL criado no hPanel. O instalador cria as tabelas e configura a loja automaticamente.</p><form method="post" action="/admin/install">' . csrf_field() . '<input type="hidden" name="key" value="' . e($given) . '"><h2 class="install-section-title">Banco MySQL</h2>';
    input_label('Servidor do banco','db_host','','required maxlength="255" placeholder="localhost ou hostname informado pela Hostinger" autocomplete="off"');
    input_label('Porta','db_port','3306','required inputmode="numeric" maxlength="5"');
    input_label('Nome do banco','db_name','','required maxlength="64" autocomplete="off"');
    input_label('Usuário do banco','db_user','','required maxlength="64" autocomplete="username"');
    input_label('Senha do banco','db_password','','required autocomplete="new-password"','password');
    echo '<h2 class="install-section-title">Administrador da loja</h2>';
    input_label('Seu nome','name','','required maxlength="120" autocomplete="name"');
    input_label('E-mail administrativo','email','','required maxlength="190" autocomplete="email"','email');
    input_label('Senha (mínimo 12 caracteres)','password','','required minlength="12" autocomplete="new-password"','password');
    input_label('Confirme a senha','password_confirm','','required minlength="12" autocomplete="new-password"','password');
    input_label('WhatsApp com código do país e DDD (opcional)','whatsapp_number','','maxlength="32" placeholder="5511999999999" autocomplete="tel"');
    echo '<button class="primary-button" type="submit">TESTAR CONEXÃO E INSTALAR</button></form><p class="install-security-note">As credenciais do banco são guardadas em um arquivo privado fora das rotas públicas. A chave do instalador é removida após a configuração.</p></div></main>';
    page_end(); exit;
}

function setup_failure(string $message, string $key): never
{
    flash('error',$message);
    redirect('/admin/install?key='.rawurlencode($key));
}
