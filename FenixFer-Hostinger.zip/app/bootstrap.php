<?php
declare(strict_types=1);

const APP_ROOT = __DIR__ . '/..';

$envFile = APP_ROOT . '/.env';
if (is_file($envFile)) {
    foreach (file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#') || !str_contains($line, '=')) continue;
        [$key, $value] = explode('=', $line, 2);
        $key = trim($key);
        $value = trim(trim($value), "\"'");
        if ($key !== '' && getenv($key) === false) putenv($key . '=' . $value);
    }
}

$isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || strtolower(trim((string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? ''))) === 'https';
session_name('fenixfer_session');
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'secure' => $isHttps,
    'httponly' => true,
    'samesite' => 'Lax',
]);
if (session_status() !== PHP_SESSION_ACTIVE) session_start();

require_once __DIR__ . '/helpers.php';

class DatabaseConfigurationRequired extends RuntimeException {}

function database_config(): array
{
    $configFile = APP_ROOT . '/storage/db-config.php';
    if (is_file($configFile)) {
        $saved = require $configFile;
        if (is_array($saved)) return $saved;
    }
    return [
        'driver' => strtolower(trim((string)(getenv('FENIX_DB_DRIVER') ?: 'sqlite'))),
        'host' => trim((string)(getenv('FENIX_DB_HOST') ?: '')),
        'port' => trim((string)(getenv('FENIX_DB_PORT') ?: '3306')),
        'database' => trim((string)(getenv('FENIX_DB_NAME') ?: '')),
        'username' => (string)(getenv('FENIX_DB_USER') ?: ''),
        'password' => (string)(getenv('FENIX_DB_PASSWORD') ?: ''),
        'path' => (string)(getenv('FENIX_DB_PATH') ?: APP_ROOT . '/storage/fenixfer.sqlite'),
    ];
}

function database_is_configured(): bool
{
    $config = database_config();
    if (($config['driver'] ?? 'sqlite') === 'sqlite') return true;
    return ($config['driver'] ?? '') === 'mysql'
        && trim((string)($config['host'] ?? '')) !== ''
        && trim((string)($config['database'] ?? '')) !== ''
        && trim((string)($config['username'] ?? '')) !== '';
}

/** Stores DB credentials outside the public assets and writes atomically. */
function save_mysql_database_config(array $config): void
{
    $host=trim((string)($config['host']??'')); $port=(int)($config['port']??3306);
    $name=trim((string)($config['database']??'')); $user=trim((string)($config['username']??'')); $password=(string)($config['password']??'');
    if (!preg_match('/^[A-Za-z0-9._:-]{1,255}$/',$host)) throw new RuntimeException('O servidor do banco contém caracteres inválidos.');
    if ($port<1 || $port>65535) throw new RuntimeException('A porta do banco é inválida.');
    if (!preg_match('/^[A-Za-z0-9_$-]{1,64}$/',$name)) throw new RuntimeException('O nome do banco contém caracteres inválidos.');
    if (!preg_match('/^[A-Za-z0-9_$-]{1,64}$/',$user)) throw new RuntimeException('O usuário do banco contém caracteres inválidos.');
    if (strlen($password)>1024) throw new RuntimeException('A senha do banco é longa demais.');
    $directory=APP_ROOT.'/storage';
    if (!is_dir($directory) && !mkdir($directory,0750,true) && !is_dir($directory)) throw new RuntimeException('Não foi possível criar o armazenamento privado.');
    $saved=['driver'=>'mysql','host'=>$host,'port'=>$port,'database'=>$name,'username'=>$user,'password'=>$password];
    $target=$directory.'/db-config.php'; $temp=$target.'.'.bin2hex(random_bytes(6)).'.tmp';
    $contents="<?php\ndeclare(strict_types=1);\nreturn ".var_export($saved,true).";\n";
    if (file_put_contents($temp,$contents,LOCK_EX)===false) throw new RuntimeException('Não foi possível salvar a configuração privada do banco.');
    @chmod($temp,0600);
    if (!rename($temp,$target)) { @unlink($temp); throw new RuntimeException('Não foi possível concluir a configuração do banco.'); }
    @chmod($target,0600);
}

function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;
    $config=database_config(); $driver=strtolower((string)($config['driver']??'sqlite'));
    $options=[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false,PDO::ATTR_TIMEOUT=>10];
    if ($driver==='mysql') {
        if (!database_is_configured()) throw new DatabaseConfigurationRequired('Configure primeiro a conexão MySQL.');
        if (!extension_loaded('pdo_mysql')) throw new RuntimeException('A hospedagem precisa habilitar a extensão pdo_mysql no PHP.');
        $host=(string)$config['host']; $port=(int)($config['port']??3306); $name=(string)$config['database'];
        $dsn='mysql:host='.$host.';port='.$port.';dbname='.$name.';charset=utf8mb4';
        $pdo=new PDO($dsn,(string)$config['username'],(string)$config['password'],$options);
        $pdo->exec("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");
        initialize_mysql_database($pdo);
        return $pdo;
    }
    if ($driver!=='sqlite') throw new RuntimeException('O driver de banco configurado não é reconhecido.');
    $path=(string)($config['path']??APP_ROOT.'/storage/fenixfer.sqlite'); $directory=dirname($path);
    if (!is_dir($directory) && !mkdir($directory,0750,true) && !is_dir($directory)) throw new RuntimeException('Não foi possível preparar a pasta do banco de dados.');
    $pdo=new PDO('sqlite:'.$path,null,null,$options);
    $pdo->exec('PRAGMA foreign_keys = ON'); $pdo->exec('PRAGMA busy_timeout = 10000'); $pdo->exec('PRAGMA journal_mode = WAL'); $pdo->exec('PRAGMA synchronous = FULL'); $pdo->exec('PRAGMA temp_store = MEMORY');
    initialize_sqlite_database($pdo);
    if (is_file($path)) @chmod($path,0640);
    return $pdo;
}

function initialize_mysql_database(PDO $pdo): void
{
    $tables=[
        "CREATE TABLE IF NOT EXISTS schema_migrations (version INT NOT NULL PRIMARY KEY, applied_at VARCHAR(40) NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        "CREATE TABLE IF NOT EXISTS categories (id VARCHAR(64) NOT NULL PRIMARY KEY, name VARCHAR(120) NOT NULL, slug VARCHAR(180) NOT NULL UNIQUE, description TEXT NOT NULL, image_url VARCHAR(2048) NOT NULL DEFAULT '', active TINYINT NOT NULL DEFAULT 1, created VARCHAR(40) NOT NULL, updated VARCHAR(40) NOT NULL, INDEX idx_categories_active_name(active,name)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        "CREATE TABLE IF NOT EXISTS products (id VARCHAR(64) NOT NULL PRIMARY KEY, name VARCHAR(160) NOT NULL, slug VARCHAR(200) NOT NULL UNIQUE, description TEXT NOT NULL, specification VARCHAR(300) NOT NULL DEFAULT '', price_in_cents BIGINT NULL, image_path VARCHAR(255) NOT NULL DEFAULT '', image_url VARCHAR(2048) NOT NULL DEFAULT '', active TINYINT NOT NULL DEFAULT 1, featured TINYINT NOT NULL DEFAULT 0, category VARCHAR(64) NOT NULL, created VARCHAR(40) NOT NULL, updated VARCHAR(40) NOT NULL, INDEX idx_products_category(category), INDEX idx_products_active_featured(active,featured), INDEX idx_products_visible_category(active,category,name), CONSTRAINT fk_products_category FOREIGN KEY(category) REFERENCES categories(id) ON UPDATE CASCADE ON DELETE RESTRICT) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        "CREATE TABLE IF NOT EXISTS staff (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, name VARCHAR(120) NOT NULL, email VARCHAR(190) NOT NULL UNIQUE, password_hash VARCHAR(255) NOT NULL, role VARCHAR(16) NOT NULL, active TINYINT NOT NULL DEFAULT 1, last_login_at VARCHAR(40) NULL, created_at VARCHAR(40) NOT NULL, INDEX idx_staff_active_role(active,role)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        "CREATE TABLE IF NOT EXISTS app_settings (setting_key VARCHAR(100) NOT NULL PRIMARY KEY, setting_value TEXT NOT NULL, updated_at VARCHAR(40) NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
    ];
    foreach($tables as $sql) $pdo->exec($sql);
    $m=$pdo->prepare('INSERT INTO schema_migrations(version,applied_at) VALUES(:version,:at) ON DUPLICATE KEY UPDATE version=VALUES(version)');
    foreach([1,2,3] as $version)$m->execute([':version'=>$version,':at'=>now_iso()]);
    seed_catalog_if_empty($pdo);
}

/** SQLite schema is retained for local development and the existing preview. */
function initialize_sqlite_database(PDO $pdo): void
{
    $pdo->exec('CREATE TABLE IF NOT EXISTS schema_migrations (version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL)');
    $pdo->exec('BEGIN IMMEDIATE');
    try {
        $pdo->exec(<<<'SQL'
CREATE TABLE IF NOT EXISTS categories (
    id TEXT PRIMARY KEY CHECK(length(id) BETWEEN 1 AND 64),
    name TEXT NOT NULL CHECK(length(trim(name)) BETWEEN 1 AND 120),
    slug TEXT NOT NULL UNIQUE CHECK(length(slug) BETWEEN 1 AND 180),
    description TEXT NOT NULL DEFAULT '' CHECK(length(description) <= 2000),
    image_url TEXT NOT NULL DEFAULT '',
    active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
    created TEXT NOT NULL,
    updated TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS products (
    id TEXT PRIMARY KEY CHECK(length(id) BETWEEN 1 AND 64),
    name TEXT NOT NULL CHECK(length(trim(name)) BETWEEN 1 AND 160),
    slug TEXT NOT NULL UNIQUE CHECK(length(slug) BETWEEN 1 AND 200),
    description TEXT NOT NULL DEFAULT '' CHECK(length(description) <= 5000),
    specification TEXT NOT NULL DEFAULT '' CHECK(length(specification) <= 300),
    price_in_cents INTEGER NULL CHECK(price_in_cents IS NULL OR price_in_cents >= 0),
    image_path TEXT NOT NULL DEFAULT '',
    image_url TEXT NOT NULL DEFAULT '',
    active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
    featured INTEGER NOT NULL DEFAULT 0 CHECK(featured IN (0,1)),
    category TEXT NOT NULL REFERENCES categories(id) ON UPDATE CASCADE ON DELETE RESTRICT,
    created TEXT NOT NULL,
    updated TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS staff (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL CHECK(length(trim(name)) BETWEEN 1 AND 120),
    email TEXT NOT NULL UNIQUE COLLATE NOCASE CHECK(length(email) <= 190),
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('admin','editor')),
    active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
    last_login_at TEXT NULL,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS app_settings (
    setting_key TEXT PRIMARY KEY CHECK(length(setting_key) BETWEEN 1 AND 100),
    setting_value TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
SQL);
        $columns=array_column($pdo->query('PRAGMA table_info(products)')->fetchAll(),'name');
        if (!in_array('image_path',$columns,true)) $pdo->exec("ALTER TABLE products ADD COLUMN image_path TEXT NOT NULL DEFAULT ''");
        foreach(['CREATE INDEX IF NOT EXISTS idx_products_category ON products(category)','CREATE INDEX IF NOT EXISTS idx_products_active_featured ON products(active,featured)','CREATE INDEX IF NOT EXISTS idx_products_visible_category ON products(active,category,name)','CREATE INDEX IF NOT EXISTS idx_categories_active_name ON categories(active,name)','CREATE INDEX IF NOT EXISTS idx_staff_active_role ON staff(active,role)'] as $sql)$pdo->exec($sql);
        $m=$pdo->prepare('INSERT OR IGNORE INTO schema_migrations(version,applied_at) VALUES(:version,:at)');
        foreach([1,2,3] as $version)$m->execute([':version'=>$version,':at'=>now_iso()]);
        $pdo->exec('COMMIT');
    } catch (Throwable $error) { $pdo->exec('ROLLBACK'); throw $error; }
    seed_catalog_if_empty($pdo);
}

function seed_catalog_if_empty(PDO $pdo): void
{
    $categoryCount=(int)$pdo->query('SELECT COUNT(*) FROM categories')->fetchColumn();
    $productCount=(int)$pdo->query('SELECT COUNT(*) FROM products')->fetchColumn();
    if ($categoryCount!==0 || $productCount!==0) return;
    $seedPath=APP_ROOT.'/data/catalog-seed.json';
    if (!is_file($seedPath)) return;
    $seed=json_decode((string)file_get_contents($seedPath),true,512,JSON_THROW_ON_ERROR);
    if (!is_array($seed)) throw new RuntimeException('O catálogo inicial está inválido.');
    $pdo->beginTransaction();
    try {
        $categoryInsert=$pdo->prepare('INSERT INTO categories(id,name,slug,description,image_url,active,created,updated) VALUES(:id,:name,:slug,:description,:image_url,:active,:created,:updated)');
        foreach(($seed['categories']??[]) as $category)$categoryInsert->execute([
            ':id'=>$category['id'],':name'=>$category['name'],':slug'=>$category['slug'],':description'=>$category['description']??'',':image_url'=>$category['image_url']??'',':active'=>!empty($category['active'])?1:0,':created'=>$category['created']??now_iso(),':updated'=>$category['updated']??now_iso(),
        ]);
        $productInsert=$pdo->prepare('INSERT INTO products(id,name,slug,description,specification,price_in_cents,image_path,image_url,active,featured,category,created,updated) VALUES(:id,:name,:slug,:description,:specification,:price_in_cents,:image_path,:image_url,:active,:featured,:category,:created,:updated)');
        foreach(($seed['products']??[]) as $product)$productInsert->execute([
            ':id'=>$product['id'],':name'=>$product['name'],':slug'=>$product['slug'],':description'=>$product['description']??'',':specification'=>$product['specification']??'',':price_in_cents'=>$product['price_in_cents']??null,':image_path'=>'',':image_url'=>$product['image_url']??'',':active'=>!empty($product['active'])?1:0,':featured'=>!empty($product['featured'])?1:0,':category'=>$product['category'],':created'=>$product['created']??now_iso(),':updated'=>$product['updated']??now_iso(),
        ]);
        $pdo->commit();
    } catch(Throwable $error) { if($pdo->inTransaction())$pdo->rollBack(); throw $error; }
}
