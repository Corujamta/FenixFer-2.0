# Fenix-Fer na Hostinger (MySQL/MariaDB)

O pacote Hostinger foi preparado para hospedagem compartilhada Web/Cloud. Nesses planos, a Hostinger usa MariaDB, compatível com a conexão MySQL desta aplicação. O banco do pacote não depende de SQLite.

## Antes de enviar os arquivos

1. No hPanel, adicione o domínio e ative o certificado SSL. O instalador só aceita o envio dos dados do banco por HTTPS.
2. Crie um **banco MySQL/MariaDB novo e vazio** e um usuário para ele. Conceda a esse usuário as permissões necessárias no banco. Guarde o hostname, nome do banco, usuário e senha para preencher o instalador. Não compartilhe a senha em mensagens.
3. Em **Websites → Dashboard → PHP Configuration**, selecione PHP 8.1 ou superior e habilite `pdo_mysql` e `fileinfo`. A disponibilidade de extensões depende da versão selecionada.
4. Na aba **PHP options**, para aceitar imagens de até 5 MB, defina `upload_max_filesize` como pelo menos `6M` e `post_max_size` como pelo menos `7M`.

A Hostinger descreve o caminho de configuração de extensões e opções no [guia oficial de PHP Configuration](https://www.hostinger.com/support/4667515-how-to-manage-php-extensions-and-options-in-hostinger/). A política de banco de dados está em [Which Database Management System is used at Hostinger](https://www.hostinger.com/support/1583226-which-database-management-system-is-used-at-hostinger/).

## Enviar e instalar

1. Faça backup do site atual antes de substituir arquivos. Extraia **o conteúdo** de `FenixFer-Hostinger.zip` diretamente em `public_html`; não deixe tudo dentro de uma subpasta. O arquivo `.htaccess` e o `index.php` da aplicação precisam ficar na raiz pública.
2. Mantenha `storage/` gravável pelo PHP. O `.htaccess` incluído bloqueia acesso público às pastas internas e às credenciais.
3. Abra o domínio em HTTPS. Na primeira visita, a loja encaminha automaticamente para a configuração inicial.
4. Preencha hostname e porta do banco, nome do banco, usuário e senha criados no hPanel. Depois, informe nome, e-mail e uma senha administrativa de pelo menos 12 caracteres. O WhatsApp com código do país e DDD é opcional.
5. Clique em **Testar conexão e instalar**. O instalador testa a conexão, cria o schema e índices, importa as sete categorias e os sete produtos iniciais, cria o administrador e se desativa. Após o redirecionamento, entre em `/admin/login`.

O pacote já inclui uma chave temporária de instalação. Ela é removida automaticamente depois que a conta administrativa é criada. As credenciais MySQL são salvas em `storage/db-config.php`, fora das rotas públicas; não mova esse arquivo para `public_html` fora da pasta `storage/`, não o envie a repositórios e não o inclua em cópias públicas.

## Depois da instalação

- Acesse `/admin/produtos` para cadastrar e editar itens. A imagem agora é enviada como arquivo JPG, PNG ou WebP; não é necessário colar uma URL. Novos arquivos são armazenados localmente em `storage/uploads/products/`.
- Em `/admin/categorias`, gerencie as categorias. Em `/admin/configuracoes`, altere o número do WhatsApp.
- Faça backup regular do banco pelo hPanel/phpMyAdmin e copie também `storage/uploads/products/` para preservar as fotos.
- Não compartilhe a senha administrativa ou os dados do banco. O projeto não processa pagamentos.

## Solução de problemas

Se aparecer erro de conexão no instalador, confira hostname, nome do banco, usuário, senha, porta e permissões. Use o banco criado para este site, sem tabelas preexistentes.

Se o envio de imagem for recusado mesmo abaixo de 5 MB, confira `upload_max_filesize` e `post_max_size` no hPanel. Se as rotas sem `.php` retornarem 404, confirme que o `.htaccess` está na raiz de `public_html` e que as regras de rewrite estão habilitadas.

Se alterar a senha do banco no hPanel, atualize também o valor correspondente em `storage/db-config.php` pelo Gerenciador de Arquivos; não cole essa senha em mensagens de suporte.
